export interface GlossaryItem {
  term: string;
  definition: string;
}

export interface PracticeQuestion {
  id: number;
  question: string;
  options: string[];
  answer: number;
}

export interface Lesson {
  id: number;
  title: string;
  videoId: string;
  takeaways: string[];
  // Extended Content
  keyConcepts?: string[];
  visual?: 'cashflow';
  formula?: string;
  practice?: PracticeQuestion[];
  glossary?: GlossaryItem[];
  interactive?: 'budget';
  worksheet?: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  answer: number;
}

export interface Unit {
  id: number;
  title: string;
  icon: string;
  color: string; // Tailwind class for background
  lessons: Lesson[];
  quiz: QuizQuestion[];
}

export interface Badge {
  id: number;
  name: string;
  icon: string;
  description: string;
  requirement: string;
}

export interface UserData {
  name: string;
  avatar: string; // ID of the selected avatar
  xp: number;
  streak: number;
  currentUnit: number;
  currentLesson: number;
  completedLessons: string[]; // Format: "unitId-lessonId"
  completedQuizzes: string[]; // Format: "unitId"
  earnedBadges: string[]; // Array of badge names
  lessonsCompleted: number;
  quizzesPassed: number;
  lastVisit: string;
  bookmarkedLessons: string[]; // Format: "unitId-lessonId"
  hapticsEnabled: boolean;
}

export type CalculatorType = 'budget' | 'sip' | 'emi' | 'compound' | null;