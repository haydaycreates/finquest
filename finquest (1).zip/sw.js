self.addEventListener('install', e => e.waitUntil(
  caches.open('finquest-v1').then(cache => 
    cache.addAll(['/', '/index.html'])
  )
));

self.addEventListener('fetch', e => 
  caches.match(e.request).then(r => r || fetch(e.request))
);