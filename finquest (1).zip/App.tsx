import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Home, BookOpen, PenTool, User, 
  Moon, Sun, Play, CheckCircle, Lock, 
  ChevronRight, ArrowLeft, Star, Flame, Award,
  ChevronLeft, Trophy, Pause, Volume2, VolumeX, RotateCcw,
  Download, PieChart as PieChartIcon, TrendingUp, DollarSign,
  Bookmark, Search, Heart, Edit2, Share2, X,
  Rocket, Target, Zap, Smartphone
} from 'lucide-react';
import ReactPlayer from 'react-player';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';
import { UserData, CalculatorType, Unit, Lesson } from './types';
import { COURSE_DATA, BADGES } from './data';
import { CalculatorModal } from './components/Calculators';

// --- HELPERS ---
const formatTime = (seconds: number) => {
  const date = new Date(seconds * 1000);
  const hh = date.getUTCHours();
  const mm = date.getUTCMinutes();
  const ss = date.getUTCSeconds().toString().padStart(2, '0');
  if (hh) {
    return `${hh}:${mm.toString().padStart(2, '0')}:${ss}`;
  }
  return `${mm}:${ss}`;
};

const AVATARS = [
  { id: '1', bg: 'bg-gradient-to-br from-red-400 to-orange-500', emoji: '🦁' },
  { id: '2', bg: 'bg-gradient-to-br from-blue-400 to-cyan-500', emoji: '🐬' },
  { id: '3', bg: 'bg-gradient-to-br from-purple-400 to-pink-500', emoji: '🦄' },
  { id: '4', bg: 'bg-gradient-to-br from-green-400 to-emerald-500', emoji: '🐸' },
  { id: '5', bg: 'bg-gradient-to-br from-yellow-400 to-amber-500', emoji: '🐝' },
  { id: '6', bg: 'bg-gradient-to-br from-indigo-400 to-violet-500', emoji: '👾' },
  { id: '7', bg: 'bg-gradient-to-br from-gray-700 to-gray-900', emoji: '🐱' }, 
  { id: '8', bg: 'bg-gradient-to-br from-rose-400 to-red-500', emoji: '🦊' },
  { id: '9', bg: 'bg-gradient-to-br from-sky-400 to-blue-600', emoji: '🐳' },
  { id: '10', bg: 'bg-gradient-to-br from-lime-400 to-green-600', emoji: '🦖' },
  { id: '11', bg: 'bg-gradient-to-br from-fuchsia-400 to-purple-600', emoji: '🐙' },
  { id: '12', bg: 'bg-gradient-to-br from-orange-400 to-red-600', emoji: '🐲' },
];

// --- COMPONENTS ---

const VideoPlayer = ({ videoId, onEnded, onProgressUpdate, startTime = 0 }: { videoId: string, onEnded?: () => void, onProgressUpdate?: (t: number) => void, startTime?: number }) => {
  const playerRef = useRef<ReactPlayer>(null);
  const [playing, setPlaying] = useState(true);
  const [volume, setVolume] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [played, setPlayed] = useState(0);
  const [duration, setDuration] = useState(0);
  const [seeking, setSeeking] = useState(false);
  const [ready, setReady] = useState(false);

  const handlePlayPause = () => setPlaying(!playing);
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setVolume(parseFloat(e.target.value));
    setMuted(parseFloat(e.target.value) === 0);
  };
  const handleToggleMute = () => setMuted(!muted);
  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPlayed(parseFloat(e.target.value));
  };
  const handleSeekMouseDown = () => setSeeking(true);
  const handleSeekMouseUp = (e: React.MouseEvent<HTMLInputElement>) => {
    setSeeking(false);
    playerRef.current?.seekTo(parseFloat((e.target as HTMLInputElement).value));
  };
  const handleProgress = (state: { played: number, playedSeconds: number }) => {
    if (!seeking) setPlayed(state.played);
    if (onProgressUpdate) onProgressUpdate(state.playedSeconds);
  };
  const handleDuration = (duration: number) => setDuration(duration);
  const handleReady = () => {
      if (!ready && startTime > 0) {
          playerRef.current?.seekTo(startTime);
          setReady(true);
      }
  };

  return (
    <div className="relative group bg-black rounded-xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-700">
      <div className="aspect-video w-full">
        <ReactPlayer
          ref={playerRef}
          url={`https://www.youtube.com/watch?v=${videoId}`}
          width="100%"
          height="100%"
          playing={playing}
          volume={volume}
          muted={muted}
          onProgress={handleProgress}
          onDuration={handleDuration}
          onEnded={onEnded}
          onReady={handleReady}
          controls={false} // Disable native controls
          config={{
             youtube: {
                playerVars: { showinfo: 0, controls: 0, modestbranding: 1, rel: 0 }
             }
          }}
        />
      </div>

      {/* Overlay Play/Pause Button (visible on hover or pause) */}
      <div 
        className={`absolute inset-0 flex items-center justify-center bg-black/30 transition-opacity duration-200 ${!playing ? 'opacity-100' : 'opacity-0 hover:opacity-100'}`}
        onClick={handlePlayPause}
      >
        <button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm p-4 rounded-full transition-transform hover:scale-110">
          {playing ? <Pause className="w-8 h-8 text-white fill-current" /> : <Play className="w-8 h-8 text-white fill-current" />}
        </button>
      </div>

      {/* Custom Control Bar */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3 flex flex-col gap-2 transition-opacity duration-200 opacity-100 md:opacity-0 md:group-hover:opacity-100">
        {/* Seek Bar */}
        <div className="w-full flex items-center gap-2 group/seek">
          <input
            type="range"
            min={0}
            max={0.999999}
            step="any"
            value={played}
            onMouseDown={handleSeekMouseDown}
            onChange={handleSeekChange}
            onMouseUp={handleSeekMouseUp}
            className="w-full h-1 bg-white/30 rounded-full appearance-none cursor-pointer hover:h-1.5 transition-all accent-emerald-500"
          />
        </div>

        {/* Controls Row */}
        <div className="flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
             <button onClick={handlePlayPause} className="hover:text-emerald-400 transition">
               {playing ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
             </button>
             
             <div className="flex items-center gap-2 group/volume">
                <button onClick={handleToggleMute} className="hover:text-emerald-400 transition">
                   {muted || volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step="any"
                  value={muted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-16 h-1 bg-white/30 rounded-full appearance-none cursor-pointer accent-emerald-500 hidden sm:block"
                />
             </div>
             
             <span className="text-xs font-medium font-mono">
               {formatTime(duration * played)} / {formatTime(duration)}
             </span>
          </div>
          
          <div className="flex items-center gap-2">
             <button 
                onClick={() => playerRef.current?.seekTo(0)} 
                className="hover:text-emerald-400 transition text-xs flex items-center gap-1"
             >
                <RotateCcw className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Replay</span>
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};


const CashFlowVisual = () => (
    <div className="flex flex-col items-center justify-center p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 my-4">
        <h4 className="text-sm font-bold text-slate-500 mb-4 uppercase tracking-wider">Simple Cash Flow</h4>
        <div className="flex items-center gap-2 md:gap-4 w-full justify-center">
            <div className="flex flex-col items-center">
                <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center border-2 border-emerald-500 mb-2">
                    <DollarSign className="w-6 h-6 md:w-8 md:h-8 text-emerald-600 dark:text-emerald-400" />
                </div>
                <span className="text-xs font-bold text-emerald-600">INCOME</span>
            </div>
            
            <div className="flex-1 h-1 bg-slate-200 dark:bg-slate-700 relative">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                   <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
            </div>

            <div className="flex flex-col items-center relative">
                 <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center border-4 border-slate-300 dark:border-slate-600 z-10">
                    <User className="w-8 h-8 text-slate-600 dark:text-slate-300" />
                </div>
                <span className="text-xs font-bold mt-2">YOU</span>
            </div>

            <div className="flex-1 h-1 bg-slate-200 dark:bg-slate-700 relative"></div>

            <div className="flex flex-col gap-4">
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-red-500"></div>
                    <span className="text-xs font-bold text-red-500">EXPENSES</span>
                 </div>
                 <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                    <span className="text-xs font-bold text-blue-500">SAVINGS</span>
                 </div>
            </div>
        </div>
    </div>
);

const InteractiveBudget = () => {
    const [income, setIncome] = useState(30000);
    const data = [
        { name: 'Needs', value: income * 0.5, color: '#10B981' },
        { name: 'Wants', value: income * 0.3, color: '#F59E0B' },
        { name: 'Savings', value: income * 0.2, color: '#3B82F6' },
    ];

    return (
        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-700 my-4">
            <h4 className="font-bold flex items-center gap-2 mb-4"><PieChartIcon className="w-4 h-4" /> Interactive Budget</h4>
            
            <div className="mb-6">
                <label className="text-xs font-bold uppercase text-slate-500 mb-1 block">Monthly Income: ₹{income.toLocaleString()}</label>
                <input 
                    type="range" 
                    min="5000" 
                    max="200000" 
                    step="1000" 
                    value={income} 
                    onChange={(e) => setIncome(parseInt(e.target.value))}
                    className="w-full accent-emerald-500"
                />
            </div>

            <div className="flex items-center gap-4">
                <div className="w-32 h-32 relative">
                     <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={data}
                                innerRadius={35}
                                outerRadius={60}
                                paddingAngle={2}
                                dataKey="value"
                            >
                                {data.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                            </Pie>
                        </PieChart>
                     </ResponsiveContainer>
                     <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                         <span className="text-[10px] font-bold">50/30/20</span>
                     </div>
                </div>
                <div className="flex-1 space-y-2 text-sm">
                    {data.map((item) => (
                        <div key={item.name} className="flex justify-between items-center">
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></div>
                                <span className="text-slate-600 dark:text-slate-300">{item.name}</span>
                            </div>
                            <span className="font-bold">₹{item.value.toLocaleString()}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};


// --- INITIAL STATE ---
const INITIAL_USER_DATA: UserData = {
  name: "Learner",
  avatar: "1",
  xp: 0,
  streak: 1,
  currentUnit: 1,
  currentLesson: 1,
  completedLessons: [],
  completedQuizzes: [],
  earnedBadges: ["First Steps"],
  lessonsCompleted: 0,
  quizzesPassed: 0,
  lastVisit: new Date().toDateString(),
  bookmarkedLessons: [],
  hapticsEnabled: true
};

const App: React.FC = () => {
  // --- STATE ---
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'home' | 'learn' | 'tools' | 'profile'>('home');
  const [darkMode, setDarkMode] = useState(true);
  const [userData, setUserData] = useState<UserData>(INITIAL_USER_DATA);
  const [activeCalculator, setActiveCalculator] = useState<CalculatorType>(null);
  
  // Lesson View State
  const [activeUnitId, setActiveUnitId] = useState<number | null>(null);
  const [activeLessonId, setActiveLessonId] = useState<number | null>(null);
  const [showLesson, setShowLesson] = useState(false);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [xpNotification, setXpNotification] = useState<{ amount: number; message: string } | null>(null);
  
  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  
  // Bookmark & Video State
  const videoTimeRef = useRef(0);
  const [resumeTime, setResumeTime] = useState(0);
  
  // Lesson Specific States
  const [practiceAnswers, setPracticeAnswers] = useState<Record<number, number>>({});
  const [practiceSubmitted, setPracticeSubmitted] = useState<Record<number, boolean>>({});

  // Level & Progress State
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [showUnitComplete, setShowUnitComplete] = useState(false);
  const [completedUnitId, setCompletedUnitId] = useState<number | null>(null);
  
  // Profile Editing State
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [editName, setEditName] = useState('');
  const [editAvatar, setEditAvatar] = useState('');

  // Derived Data
  const totalLessons = useMemo(() => COURSE_DATA.reduce((acc, unit) => acc + unit.lessons.length, 0), []);
  const overallProgress = Math.round((userData.completedLessons.length / totalLessons) * 100);
  const currentLevel = Math.floor(userData.xp / 100) + 1;
  const prevLevelRef = useRef(currentLevel);

  // --- HAPTIC HELPER ---
  const triggerHaptic = (pattern: number | number[] = 10) => {
      if (userData.hapticsEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
          navigator.vibrate(pattern);
      }
  };

  // --- EFFECTS ---
  useEffect(() => {
    // Load data
    const saved = localStorage.getItem('finquest_data');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Streak Logic
      const today = new Date().toDateString();
      const lastVisit = new Date(parsed.lastVisit);
      const diffTime = Math.abs(new Date(today).getTime() - lastVisit.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
      
      if (diffDays === 1) parsed.streak += 1;
      else if (diffDays > 1) parsed.streak = 1;
      
      parsed.lastVisit = today;
      // Ensure properties exist if loading old data
      if (!parsed.bookmarkedLessons) parsed.bookmarkedLessons = [];
      if (!parsed.name) parsed.name = "Learner";
      if (!parsed.avatar) parsed.avatar = "1";
      if (parsed.hapticsEnabled === undefined) parsed.hapticsEnabled = true;
      
      setUserData(parsed);
      
      // Sync level ref to prevent level up on load
      prevLevelRef.current = Math.floor(parsed.xp / 100) + 1;
    }
    
    // Check system preference for dark mode
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setDarkMode(true);
    }

    setTimeout(() => setLoading(false), 1500);
  }, []);

  useEffect(() => {
    // Check for level up
    if (currentLevel > prevLevelRef.current) {
        setShowLevelUp(true);
        triggerHaptic([100, 50, 100, 50, 100]); // Heavy pulse pattern
    }
    prevLevelRef.current = currentLevel;
  }, [currentLevel]);

  useEffect(() => {
    localStorage.setItem('finquest_data', JSON.stringify(userData));
  }, [userData]);

  useEffect(() => {
    if (darkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [darkMode]);

  // --- ACTIONS ---
  const addXP = (amount: number, message: string = "XP Earned!") => {
    setUserData(prev => ({ ...prev, xp: prev.xp + amount }));
    setXpNotification({ amount, message });
    triggerHaptic([50, 30, 50]); // Success pattern
    setTimeout(() => setXpNotification(null), 3000);
  };

  const checkBadges = () => {
    const newBadges: string[] = [];
    // Badge Logic
    if (userData.lessonsCompleted >= 1 && !userData.earnedBadges.includes("First Steps")) newBadges.push("First Steps");
    if (userData.streak >= 7 && !userData.earnedBadges.includes("Week Warrior")) newBadges.push("Week Warrior");
    if (userData.quizzesPassed >= 10 && !userData.earnedBadges.includes("Quiz Wizard")) newBadges.push("Quiz Wizard");
    
    // Unit Badges
    const unitBadges: Record<number, string> = {
        2: 'Budget Boss', 3: 'Credit Master', 4: 'Goal Getter',
        5: 'Debt Destroyer', 6: 'Safety Shield', 7: 'Investment Pro', 8: 'Fraud Fighter'
    };
    
    Object.entries(unitBadges).forEach(([unitId, badgeName]) => {
        const uid = parseInt(unitId);
        const unit = COURSE_DATA.find(u => u.id === uid);
        if (unit) {
             const completedCount = userData.completedLessons.filter(l => l.startsWith(`${uid}-`)).length;
             if (completedCount === unit.lessons.length && !userData.earnedBadges.includes(badgeName)) {
                 newBadges.push(badgeName);
             }
        }
    });

    // New Logic for Halfway Hero and Finance Master
    const totalLessonsCount = COURSE_DATA.reduce((acc, unit) => acc + unit.lessons.length, 0);
    const completedCount = userData.completedLessons.length;
    
    if (completedCount >= Math.floor(totalLessonsCount / 2) && !userData.earnedBadges.includes("Halfway Hero")) {
        newBadges.push("Halfway Hero");
    }
    
    if (completedCount === totalLessonsCount && completedCount > 0 && !userData.earnedBadges.includes("Finance Master")) {
        newBadges.push("Finance Master");
    }

    if (newBadges.length > 0) {
        setUserData(prev => ({...prev, earnedBadges: [...prev.earnedBadges, ...newBadges]}));
        triggerHaptic([50, 50, 100]); // Badge earned pattern
    }
  };

  const handleLessonOpen = (unitId: number, lessonId: number) => {
    triggerHaptic(15);
    setActiveUnitId(unitId);
    setActiveLessonId(lessonId);
    setShowLesson(true);
    setVideoLoaded(false);
    setQuizAnswers([]);
    setQuizSubmitted(false);
    setPracticeAnswers({});
    setPracticeSubmitted({});
    
    // Reset video time logic
    videoTimeRef.current = 0;
    const savedBookmark = localStorage.getItem(`bookmark_${unitId}_${lessonId}`);
    setResumeTime(savedBookmark ? parseFloat(savedBookmark) : 0);

    // Mark viewed logic
    const lessonKey = `${unitId}-${lessonId}`;
    if (!userData.completedLessons.includes(lessonKey)) {
        setUserData(prev => ({
            ...prev,
            completedLessons: [...prev.completedLessons, lessonKey],
            lessonsCompleted: prev.lessonsCompleted + 1,
            currentUnit: unitId,
            currentLesson: lessonId
        }));
        addXP(25, "Lesson Completed!");
        checkBadges();
    }
  };

  const handleSaveTimestamp = () => {
    triggerHaptic(10);
    if (activeUnitId && activeLessonId && videoTimeRef.current > 0) {
        localStorage.setItem(`bookmark_${activeUnitId}_${activeLessonId}`, videoTimeRef.current.toString());
        // Could trigger a toast here
        alert("Timestamp saved! You can resume video from here later.");
    }
  };

  const toggleBookmark = (unitId: number, lessonId: number) => {
    triggerHaptic(10);
    const key = `${unitId}-${lessonId}`;
    setUserData(prev => {
        const isBookmarked = prev.bookmarkedLessons.includes(key);
        const newBookmarks = isBookmarked
            ? prev.bookmarkedLessons.filter(k => k !== key)
            : [...prev.bookmarkedLessons, key];
        return { ...prev, bookmarkedLessons: newBookmarks };
    });
  };

  const handleQuizSubmit = (unitId: number) => {
    const unit = COURSE_DATA.find(u => u.id === unitId);
    if (!unit) return;

    let correct = 0;
    unit.quiz.forEach((q, i) => {
        if (quizAnswers[i] === q.answer) correct++;
    });

    setQuizSubmitted(true);
    const quizKey = `unit-${unitId}`;
    
    if (correct >= 2) {
        if (!userData.completedQuizzes.includes(quizKey)) {
             setUserData(prev => ({
                ...prev,
                completedQuizzes: [...prev.completedQuizzes, quizKey],
                quizzesPassed: prev.quizzesPassed + 1
            }));
            addXP(50, "Quiz Passed!");
            checkBadges();
        } else {
             triggerHaptic([50, 30]); // Already passed but good job
        }
    } else {
        triggerHaptic([50, 50]); // Failed pattern
    }
  };

  const handleLessonNavigate = (direction: 'next' | 'prev') => {
      triggerHaptic(10);
      if (!activeUnitId || !activeLessonId) return;
      const unit = COURSE_DATA.find(u => u.id === activeUnitId);
      if (!unit) return;

      if (direction === 'next') {
          if (activeLessonId < unit.lessons.length) {
              handleLessonOpen(activeUnitId, activeLessonId + 1);
          } else {
              // End of unit
              setShowLesson(false);
              setCompletedUnitId(activeUnitId);
              setShowUnitComplete(true);
              triggerHaptic([50, 50, 50]); // Unit Complete Pattern

              if (activeUnitId < COURSE_DATA.length) {
                  setUserData(prev => {
                      if (prev.currentUnit <= activeUnitId) {
                          return {...prev, currentUnit: activeUnitId + 1, currentLesson: 1};
                      }
                      return prev;
                  });
              }
          }
      } else {
          if (activeLessonId > 1) {
              handleLessonOpen(activeUnitId, activeLessonId - 1);
          }
      }
  };

  const openProfileEdit = () => {
      triggerHaptic(10);
      setEditName(userData.name);
      setEditAvatar(userData.avatar);
      setShowProfileModal(true);
  };

  const saveProfile = () => {
      triggerHaptic(15);
      setUserData(prev => ({...prev, name: editName, avatar: editAvatar}));
      setShowProfileModal(false);
  };

  const shareProfile = async () => {
      triggerHaptic(10);
      if (navigator.share) {
          try {
              const currentUrl = window.location.href;
              const urlToShare = currentUrl.startsWith('http') ? currentUrl : 'https://finquest.app';
              
              await navigator.share({
                  title: 'My FinQuest Profile',
                  text: `I'm learning finance on FinQuest! I'm Level ${currentLevel} with ${userData.xp} XP.`,
                  url: urlToShare
              });
          } catch (error) {
              console.error("Error sharing:", error);
          }
      } else {
          alert("Profile Saved! (Sharing not supported on this device)");
          setShowProfileModal(false);
      }
  };


  // --- RENDER HELPERS ---
  
  if (loading) {
    return (
      <div className="fixed inset-0 bg-white dark:bg-slate-900 z-50 flex flex-col items-center justify-center text-slate-900 dark:text-white transition-colors">
        <div className="text-6xl mb-4 animate-float">🚀</div>
        <h1 className="text-3xl font-bold mb-2">FinQuest</h1>
        <p className="text-emerald-500 dark:text-emerald-400">Loading your journey...</p>
        <div className="mt-8 w-48 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
             <div className="h-full bg-emerald-500 rounded-full animate-pulse-slow w-2/3"></div>
        </div>
      </div>
    );
  }

  // XP Notification Popup
  const NotificationPopup = () => (
      xpNotification ? (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-slate-800 text-white px-6 py-4 rounded-2xl shadow-2xl z-[100] animate-in slide-in-from-top-4 fade-in duration-300 flex items-center gap-4 border border-slate-700">
            <div className="bg-amber-500 rounded-full p-2 animate-bounce">
                <Award className="w-6 h-6 text-white" />
            </div>
            <div>
                <h4 className="font-bold text-lg leading-none mb-1">{xpNotification.message}</h4>
                <p className="text-amber-400 font-bold text-sm">+{xpNotification.amount} XP</p>
            </div>
        </div>
      ) : null
  );

  const currentAvatar = AVATARS.find(a => a.id === userData.avatar) || AVATARS[0];

  return (
    <div className="pb-20 max-w-lg mx-auto bg-slate-50 dark:bg-slate-950 min-h-screen shadow-2xl border-x border-slate-200 dark:border-slate-800 relative text-slate-900 dark:text-slate-100 font-sans selection:bg-emerald-500/30 transition-colors">
      <NotificationPopup />

      {/* Level Up Modal */}
      {showLevelUp && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl text-center max-w-sm mx-4 shadow-2xl animate-in zoom-in-50 duration-300 relative overflow-hidden border border-slate-200 dark:border-slate-800">
                <div className="absolute inset-0 pointer-events-none opacity-20">
                     <div className="absolute top-0 left-0 w-32 h-32 bg-yellow-400 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
                     <div className="absolute bottom-0 right-0 w-32 h-32 bg-emerald-500 rounded-full blur-3xl translate-x-1/2 translate-y-1/2"></div>
                </div>
                <div className="text-6xl mb-4 animate-bounce">🆙</div>
                <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-blue-500 mb-2">LEVEL UP!</h2>
                <p className="text-slate-500 dark:text-slate-400 mb-6">You are now Level <span className="text-slate-900 dark:text-white font-bold text-xl">{currentLevel}</span></p>
                <button 
                    onClick={() => {
                        triggerHaptic(15);
                        setShowLevelUp(false);
                    }}
                    className="w-full py-3 rounded-xl bg-emerald-500 text-white font-bold hover:bg-emerald-600 transition shadow-lg shadow-emerald-500/30 relative z-10"
                >
                    Continue
                </button>
            </div>
        </div>
      )}

      {/* Profile Edit Modal */}
      {showProfileModal && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 w-full max-w-sm mx-4 rounded-2xl overflow-hidden shadow-2xl animate-in zoom-in-50 duration-200 border border-slate-200 dark:border-slate-800">
                <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
                    <h3 className="font-bold text-lg text-slate-900 dark:text-white">Edit Profile</h3>
                    <button onClick={() => {
                        triggerHaptic(10);
                        setShowProfileModal(false);
                    }}><X className="w-5 h-5 text-slate-500" /></button>
                </div>
                
                <div className="p-6 space-y-6">
                    <div>
                        <label className="block text-sm font-bold text-slate-500 mb-2">Choose Avatar</label>
                        <div className="grid grid-cols-4 gap-3">
                            {AVATARS.map((avatar) => (
                                <button
                                    key={avatar.id}
                                    onClick={() => {
                                        triggerHaptic(5);
                                        setEditAvatar(avatar.id);
                                    }}
                                    className={`aspect-square rounded-xl flex items-center justify-center text-2xl transition-transform ${avatar.bg} ${editAvatar === avatar.id ? 'ring-4 ring-emerald-500/50 scale-110 shadow-lg' : 'hover:scale-105 opacity-80'}`}
                                >
                                    {avatar.emoji}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-bold text-slate-500 mb-2">Display Name</label>
                        <input 
                            type="text" 
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            maxLength={12}
                            placeholder="Enter name"
                            className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-bold text-center"
                        />
                        <p className="text-xs text-right text-slate-500 mt-1">{editName.length}/12</p>
                    </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex gap-3">
                    <button onClick={saveProfile} className="flex-1 bg-emerald-500 text-white font-bold py-3 rounded-xl hover:bg-emerald-600 transition">Save Changes</button>
                    <button onClick={shareProfile} className="px-4 py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition flex items-center justify-center gap-2 font-bold">
                        <Share2 className="w-5 h-5" />
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Unit Completion Modal */}
      {showUnitComplete && completedUnitId && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl text-center max-w-sm mx-4 shadow-2xl animate-in zoom-in-50 duration-300 relative overflow-hidden border border-slate-200 dark:border-slate-800">
                <div className="absolute inset-0 pointer-events-none opacity-20">
                     <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
                     <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500 rounded-full blur-3xl -translate-x-1/2 translate-y-1/2"></div>
                </div>
                
                <div className="text-6xl mb-4 animate-bounce">🎉</div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">UNIT COMPLETED!</h2>
                
                <p className="text-emerald-500 font-bold mb-4">
                    {COURSE_DATA.find(u => u.id === completedUnitId)?.title}
                </p>

                {(() => {
                   const badgeName = {
                      2: 'Budget Boss', 3: 'Credit Master', 4: 'Goal Getter',
                      5: 'Debt Destroyer', 6: 'Safety Shield', 7: 'Investment Pro', 8: 'Fraud Fighter'
                   }[completedUnitId];
                   
                   const hasBadge = badgeName ? userData.earnedBadges.includes(badgeName) : false;
                   const badgeInfo = BADGES.find(b => b.name === badgeName);

                   return hasBadge && badgeInfo ? (
                       <div className="bg-amber-100 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-900/50 p-4 rounded-2xl mb-6 mx-auto inline-block animate-in slide-in-from-bottom-2 fade-in duration-500">
                            <div className="text-4xl mb-2">{badgeInfo.icon}</div>
                            <div className="font-bold text-amber-600 dark:text-amber-400 text-sm">{badgeInfo.name} Unlocked!</div>
                       </div>
                   ) : (
                       <p className="text-slate-500 dark:text-slate-400 mb-6 text-sm">
                          You've mastered this topic. Keep the momentum going!
                       </p>
                   );
                })()}

                <button 
                    onClick={() => {
                        triggerHaptic(15);
                        setShowUnitComplete(false);
                        setCompletedUnitId(null);
                        setActiveTab('learn');
                    }}
                    className="w-full py-3 rounded-xl bg-emerald-500 text-white font-bold hover:bg-emerald-600 transition shadow-lg shadow-emerald-500/30 relative z-10"
                >
                    Continue Journey
                </button>
            </div>
        </div>
      )}
      
      {/* Header - Hidden on Home for the immersive dashboard look, visible on others */}
      {!showLesson && activeTab !== 'home' && (
        <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between transition-colors">
            <div className="flex items-center gap-2">
                <span className="text-2xl">💰</span>
                <span className="font-bold text-xl text-emerald-600 dark:text-emerald-400">FinQuest</span>
            </div>
            <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-rose-100 dark:bg-rose-900/40 px-3 py-1 rounded-full">
                    <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
                    <span className="font-bold text-rose-700 dark:text-rose-400 text-sm">{userData.bookmarkedLessons.length}</span>
                </div>
                <button 
                    onClick={() => {
                        triggerHaptic(10);
                        setActiveTab('profile');
                    }}
                    className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 pr-3 pl-1 py-1 rounded-full cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${currentAvatar.bg}`}>
                        {currentAvatar.emoji}
                    </div>
                    <span className="font-bold text-slate-700 dark:text-slate-300 text-sm">{userData.xp} XP</span>
                </button>
                <button onClick={() => {
                    triggerHaptic(10);
                    setDarkMode(!darkMode);
                }} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                    {darkMode ? <Sun className="w-5 h-5 text-slate-400" /> : <Moon className="w-5 h-5 text-slate-600" />}
                </button>
            </div>
        </header>
      )}

      {/* Main Content Areas */}
      <main className="animate-in fade-in duration-300">
        
        {/* HOME TAB - NEW UI */}
        {activeTab === 'home' && !showLesson && (
          <div className="p-4 space-y-5">
            {/* Hero Card */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-900 via-emerald-800 to-teal-900 p-6 shadow-2xl border border-emerald-500/20">
              {/* Background decoration */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-teal-400/10 rounded-full blur-2xl translate-y-1/2 -translate-x-1/2"></div>

              <div className="relative z-10">
                <h1 className="text-2xl font-bold mb-2 text-white">Master Your Money,<br/>Master Your Future 🚀</h1>
                <p className="text-emerald-100/80 text-sm mb-6">Keep your {userData.streak} day streak alive and level up!</p>

                <button
                  onClick={() => {
                      triggerHaptic(10);
                      setActiveTab('learn');
                  }}
                  className="w-full bg-gradient-to-r from-yellow-300 to-amber-400 hover:from-yellow-200 hover:to-amber-300 text-slate-900 font-bold py-3.5 rounded-2xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <Rocket className="w-5 h-5" /> Continue Your Journey
                </button>

                <div className="flex items-center justify-between mt-6 text-xs font-medium text-emerald-200/60">
                   <span className="flex items-center gap-1.5"><Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-500"/> {12400 + userData.streak * 5} learners active</span>
                   <span className="bg-yellow-400/20 text-yellow-300 px-2 py-0.5 rounded-lg border border-yellow-400/30">+10 XP</span>
                </div>
              </div>
            </div>

            {/* Today's Goal */}
            <div className="relative rounded-3xl bg-white dark:bg-gradient-to-r dark:from-slate-900 dark:to-slate-800 p-5 border border-slate-200 dark:border-slate-700/50 shadow-xl overflow-hidden transition-colors">
               {/* Sparkles - Only visible in dark mode primarily, but kept subtle */}
               <div className="absolute top-2 right-4 text-yellow-400/20 text-xs">✨</div>
               <div className="absolute bottom-4 left-10 text-yellow-400/10 text-xl">✨</div>

               <div className="flex items-center justify-between mb-3 relative z-10">
                  <div className="flex items-center gap-2 text-yellow-500 dark:text-yellow-400 font-bold">
                     <Target className="w-5 h-5" /> Today's Goal
                  </div>
               </div>
               <p className="text-slate-600 dark:text-slate-300 text-sm mb-4 relative z-10">Complete one short lesson (~3 mins)</p>
               <div className="flex items-center gap-4 relative z-10">
                   <div className="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 transition-all duration-500" style={{ width: userData.lessonsCompleted > 0 ? '100%' : '0%' }}></div>
                   </div>
                   <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">{userData.lessonsCompleted > 0 ? '1/1' : '0/1'}</span>
                   <button onClick={() => {
                       triggerHaptic(10);
                       setActiveTab('learn');
                   }} className="bg-gradient-to-r from-amber-400 to-orange-400 text-slate-900 text-xs font-bold px-4 py-2 rounded-xl shadow-lg shadow-orange-500/20">
                      {userData.lessonsCompleted > 0 ? 'Done' : 'Start'}
                   </button>
               </div>
            </div>

            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200 px-1">Your Progress</h3>

            {/* Avatar & Progress */}
            <div className="relative rounded-3xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700/50 p-4 shadow-lg backdrop-blur-sm transition-colors">
               <div className="flex items-center gap-4">
                   <div className={`w-14 h-14 rounded-2xl ${currentAvatar.bg} flex items-center justify-center text-3xl shadow-inner border border-white/10`}>
                      {currentAvatar.emoji}
                   </div>
                   <div className="flex-1">
                      <div className="flex justify-between items-end mb-2">
                         <div>
                            <h4 className="font-bold text-slate-900 dark:text-white">Explorer</h4>
                            <p className="text-xs text-slate-500 dark:text-slate-400">Level {currentLevel}</p>
                         </div>
                         <span className="text-xl font-bold text-emerald-500 dark:text-emerald-400">{overallProgress}%</span>
                      </div>
                      <div className="h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden border border-slate-200 dark:border-slate-700">
                         <div className="h-full bg-gradient-to-r from-teal-400 to-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] transition-all duration-1000" style={{ width: `${Math.max(5, overallProgress)}%` }}></div>
                      </div>
                   </div>
               </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-3">
                <div className="rounded-2xl bg-white dark:bg-gradient-to-b dark:from-slate-800 dark:to-slate-900 p-4 border border-slate-200 dark:border-slate-700/50 flex flex-col items-center justify-center gap-1 shadow-lg relative overflow-hidden transition-colors">
                     <div className="absolute inset-0 bg-orange-500/5 blur-xl"></div>
                     <Flame className="w-8 h-8 text-orange-500 fill-orange-500 drop-shadow-[0_0_8px_rgba(249,115,22,0.5)]" />
                     <span className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{userData.streak}</span>
                     <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Day Streak</span>
                </div>
                <div className="rounded-2xl bg-white dark:bg-gradient-to-b dark:from-slate-800 dark:to-slate-900 p-4 border border-slate-200 dark:border-slate-700/50 flex flex-col items-center justify-center gap-1 shadow-lg relative overflow-hidden transition-colors">
                     <div className="absolute inset-0 bg-yellow-500/5 blur-xl"></div>
                     <Star className="w-8 h-8 text-yellow-400 fill-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]" />
                     <span className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{userData.xp}</span>
                     <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Total XP</span>
                </div>
                <div className="rounded-2xl bg-white dark:bg-gradient-to-b dark:from-slate-800 dark:to-slate-900 p-4 border border-slate-200 dark:border-slate-700/50 flex flex-col items-center justify-center gap-1 shadow-lg relative overflow-hidden transition-colors">
                     <div className="absolute inset-0 bg-purple-500/5 blur-xl"></div>
                     <div className="relative">
                        <Trophy className="w-8 h-8 text-purple-400 drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]" />
                        <span className="absolute -top-1 -right-2 bg-emerald-500 text-slate-900 text-[9px] font-bold px-1.5 rounded-full">+5 XP</span>
                     </div>
                     <span className="text-2xl font-bold text-slate-900 dark:text-white mt-1">{userData.earnedBadges.length}</span>
                     <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold">Badges</span>
                </div>
            </div>

            {/* Streak Risk */}
            <div className="rounded-2xl bg-red-50 dark:bg-slate-900/50 border border-red-200 dark:border-red-500/20 p-4 flex items-center gap-4 relative overflow-hidden group transition-colors">
                <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent opacity-50"></div>
                <div className="p-2.5 bg-red-500/20 rounded-xl text-red-500 relative z-10">
                    <Flame className="w-5 h-5 fill-current" />
                </div>
                <div className="relative z-10">
                    <h4 className="text-red-500 dark:text-red-400 font-bold text-sm">Streak at risk!</h4>
                    <p className="text-slate-500 dark:text-slate-400 text-xs">Don't break it! <span className="text-slate-700 dark:text-slate-300 font-mono">2h 59m</span> left</p>
                </div>
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-red-500/50 to-transparent"></div>
            </div>
            
            {/* Quick Tools Access - Styled Dark */}
            <div>
                <div className="flex items-center justify-between mb-3 mt-2">
                    <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200">Tools 🛠️</h3>
                    <button onClick={() => {
                        triggerHaptic(10);
                        setActiveTab('tools');
                    }} className="text-sm text-emerald-600 dark:text-emerald-400 font-medium hover:underline">View All</button>
                </div>
                <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-2">
                    {[
                        { id: 'budget', icon: '📊', name: 'Budget' },
                        { id: 'sip', icon: '📈', name: 'SIP' },
                        { id: 'emi', icon: '🏦', name: 'EMI' },
                    ].map((tool) => (
                        <button 
                            key={tool.id}
                            onClick={() => {
                                triggerHaptic(10);
                                setActiveCalculator(tool.id as CalculatorType);
                            }}
                            className="flex-shrink-0 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm hover:border-emerald-500/50 transition min-w-[90px] flex flex-col items-center gap-2 group"
                        >
                            <span className="text-xl group-hover:scale-110 transition-transform">{tool.icon}</span>
                            <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">{tool.name}</span>
                        </button>
                    ))}
                </div>
            </div>
          </div>
        )}

        {/* LEARN TAB */}
        {activeTab === 'learn' && !showLesson && (
            <div className="p-4 space-y-4">
                <div className="flex justify-between items-center mb-2">
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white">Learning Path 📚</h2>
                </div>
                
                {/* Search Bar */}
                <div className="relative mb-4">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-slate-400" />
                    </div>
                    <input 
                        type="text"
                        placeholder="Search lessons..." 
                        className="w-full pl-10 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 outline-none text-slate-900 dark:text-white placeholder-slate-500"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>

                {searchQuery ? (
                    <div className="space-y-3">
                        {COURSE_DATA.flatMap(unit => 
                            unit.lessons.filter(l => l.title.toLowerCase().includes(searchQuery.toLowerCase())).map(lesson => ({ unit, lesson }))
                        ).map(({ unit, lesson }) => (
                            <button
                                key={`${unit.id}-${lesson.id}`}
                                onClick={() => handleLessonOpen(unit.id, lesson.id)}
                                className="w-full bg-white dark:bg-slate-900 rounded-xl p-4 shadow-sm border border-slate-200 dark:border-slate-700 text-left hover:border-emerald-500/50 transition-all flex items-center justify-between group"
                            >
                                <div>
                                    <div className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mb-1">{unit.title}</div>
                                    <div className="font-bold text-slate-800 dark:text-slate-200">{lesson.title}</div>
                                </div>
                                <Play className="w-4 h-4 text-slate-400 group-hover:text-emerald-400" />
                            </button>
                        ))}
                        {COURSE_DATA.flatMap(unit => unit.lessons).filter(l => l.title.toLowerCase().includes(searchQuery.toLowerCase())).length === 0 && (
                            <div className="text-center py-8 text-slate-500">
                                No lessons found matching "{searchQuery}"
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="space-y-3">
                        {COURSE_DATA.map((unit, index) => {
                            const isLocked = index > 0 && userData.currentUnit < unit.id;
                            const completedLessons = userData.completedLessons.filter(l => l.startsWith(`${unit.id}-`)).length;
                            const progress = (completedLessons / unit.lessons.length) * 100;
                            const isComplete = progress === 100;

                            return (
                                <button
                                    key={unit.id}
                                    disabled={isLocked}
                                    onClick={() => handleLessonOpen(unit.id, 1)}
                                    className={`w-full bg-white dark:bg-slate-900 rounded-xl p-4 shadow-sm border border-slate-200 dark:border-slate-700 text-left transition-all ${isLocked ? 'opacity-60 grayscale' : 'hover:border-emerald-500/50 active:scale-[0.99]'}`}
                                >
                                    <div className="flex items-center gap-4">
                                        <div className={`w-14 h-14 ${unit.color} rounded-2xl flex items-center justify-center text-2xl`}>
                                            {isLocked ? <Lock className="w-6 h-6 text-slate-400" /> : unit.icon}
                                        </div>
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2 mb-1">
                                                <h4 className="font-bold text-slate-900 dark:text-slate-100">Unit {unit.id}</h4>
                                                {isComplete && <span className="text-[10px] bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">DONE</span>}
                                            </div>
                                            <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-1">{unit.title}</p>
                                            <div className="mt-3 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                                                <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
                                            </div>
                                        </div>
                                    </div>
                                </button>
                            )
                        })}
                    </div>
                )}
            </div>
        )}

        {/* TOOLS TAB */}
        {activeTab === 'tools' && (
            <div className="p-4 space-y-4">
                <h2 className="text-xl font-bold mb-2 text-slate-900 dark:text-white">Financial Tools 🧮</h2>
                <div className="grid grid-cols-1 gap-4">
                     {[
                        { id: 'budget', icon: '📊', name: '50-30-20 Budget', desc: 'Allocate your income wisely' },
                        { id: 'sip', icon: '📈', name: 'SIP Calculator', desc: 'Plan mutual fund wealth' },
                        { id: 'emi', icon: '🏦', name: 'EMI Calculator', desc: 'Estimate loan repayments' },
                        { id: 'compound', icon: '💹', name: 'Compound Interest', desc: 'Visualize exponential growth' }
                    ].map((tool) => (
                        <button 
                            key={tool.id}
                            onClick={() => {
                                triggerHaptic(10);
                                setActiveCalculator(tool.id as CalculatorType);
                            }}
                            className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-700 text-left flex items-center gap-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
                        >
                            <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center text-2xl">
                                {tool.icon}
                            </div>
                            <div className="flex-1">
                                <h4 className="font-bold text-slate-900 dark:text-slate-100">{tool.name}</h4>
                                <p className="text-sm text-slate-500 dark:text-slate-400">{tool.desc}</p>
                            </div>
                            <ChevronRight className="w-5 h-5 text-slate-500" />
                        </button>
                    ))}
                </div>
            </div>
        )}

        {/* PROFILE TAB */}
        {activeTab === 'profile' && (
            <div className="p-4 space-y-6">
                 <div className="bg-gradient-to-br from-emerald-600 to-teal-800 rounded-2xl p-6 text-white relative overflow-hidden shadow-lg">
                    <div className="flex items-center gap-4 mb-4 relative z-10">
                        <div className={`w-20 h-20 rounded-full flex items-center justify-center text-4xl shadow-lg border-2 border-white/20 ${currentAvatar.bg}`}>
                            {currentAvatar.emoji}
                        </div>
                        <div className="flex-1">
                            <h2 className="text-2xl font-bold">{userData.name}</h2>
                            <p className="text-emerald-100 text-sm">Level {Math.floor(userData.xp / 100) + 1} • {userData.xp} XP</p>
                            <button onClick={openProfileEdit} className="mt-2 text-xs bg-black/20 hover:bg-black/30 px-3 py-1 rounded-full flex items-center gap-1 transition border border-white/10">
                                <Edit2 className="w-3 h-3" /> Edit Profile
                            </button>
                        </div>
                    </div>
                    <div className="h-2 bg-black/20 rounded-full overflow-hidden relative z-10">
                        <div className="h-full bg-white/90 rounded-full transition-all" style={{ width: `${userData.xp % 100}%` }}></div>
                    </div>
                    <p className="text-xs text-emerald-100 mt-2 text-right relative z-10">{100 - (userData.xp % 100)} XP to next level</p>
                    
                    {/* Decorative Background Icon */}
                    <div className="absolute -right-4 -bottom-4 text-9xl opacity-10 grayscale pointer-events-none">
                        {currentAvatar.emoji}
                    </div>
                </div>

                {/* Earned Badges List */}
                <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-700">
                    <h3 className="font-bold mb-4 flex items-center gap-2 text-slate-900 dark:text-white">My Achievements 🏆</h3>
                    {userData.earnedBadges.length > 0 ? (
                        <div className="space-y-4">
                            {userData.earnedBadges.map((badgeName, index) => {
                                const badge = BADGES.find(b => b.name === badgeName);
                                if (!badge) return null;
                                return (
                                    <div key={index} className="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                                        <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center text-2xl shrink-0 border border-amber-500/20">
                                            {badge.icon}
                                        </div>
                                        <div>
                                            <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm">{badge.name}</h4>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">{badge.description}</p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        <p className="text-slate-500 text-sm text-center py-4">No badges earned yet. Keep learning!</p>
                    )}
                </div>

                {/* All Badges Grid */}
                <div className="bg-white dark:bg-slate-900 rounded-xl p-5 shadow-sm border border-slate-200 dark:border-slate-700 opacity-80">
                    <h3 className="font-bold mb-4 text-sm text-slate-500 uppercase tracking-wider">All Badges</h3>
                    <div className="grid grid-cols-4 gap-4">
                        {BADGES.map(badge => {
                            const earned = userData.earnedBadges.includes(badge.name);
                            return (
                                <div key={badge.id} className={`flex flex-col items-center text-center ${earned ? '' : 'opacity-40 grayscale'}`}>
                                    <div className={`w-12 h-12 ${earned ? 'bg-amber-100 dark:bg-amber-900/30 border border-amber-500/30' : 'bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700'} rounded-full flex items-center justify-center text-xl mb-1`}>
                                        {earned ? badge.icon : '🔒'}
                                    </div>
                                    <span className="text-[10px] font-medium leading-tight text-slate-600 dark:text-slate-400">{badge.name}</span>
                                </div>
                            )
                        })}
                    </div>
                </div>

                {/* Simple Settings */}
                <div className="bg-white dark:bg-slate-900 rounded-xl overflow-hidden shadow-sm border border-slate-200 dark:border-slate-700">
                    <div className="p-4 border-b border-slate-200 dark:border-slate-800 font-bold text-slate-900 dark:text-white">Settings</div>
                    <div className="divide-y divide-slate-200 dark:divide-slate-800">
                         <div className="p-4 flex items-center justify-between">
                            <span className="text-sm text-slate-700 dark:text-slate-300">Dark Mode</span>
                            <button onClick={() => {
                                triggerHaptic(10);
                                setDarkMode(!darkMode);
                            }} className={`w-10 h-6 rounded-full p-1 transition-colors ${darkMode ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                                <div className={`w-4 h-4 bg-white rounded-full transition-transform ${darkMode ? 'translate-x-4' : ''}`} />
                            </button>
                        </div>
                        <div className="p-4 flex items-center justify-between">
                            <span className="text-sm text-slate-700 dark:text-slate-300">Haptic Feedback</span>
                            <button onClick={() => {
                                const newVal = !userData.hapticsEnabled;
                                setUserData(prev => ({...prev, hapticsEnabled: newVal}));
                                if (newVal && typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(20);
                            }} className={`w-10 h-6 rounded-full p-1 transition-colors ${userData.hapticsEnabled ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                                <div className={`w-4 h-4 bg-white rounded-full transition-transform ${userData.hapticsEnabled ? 'translate-x-4' : ''}`} />
                            </button>
                        </div>
                         <div className="p-4 flex items-center justify-between">
                            <span className="text-sm text-slate-700 dark:text-slate-300">Reset Progress</span>
                            <button onClick={() => {
                                triggerHaptic(10);
                                if(confirm("Are you sure? This cannot be undone.")) {
                                    setUserData(INITIAL_USER_DATA);
                                    window.location.reload();
                                }
                            }} className="text-xs text-red-500 dark:text-red-400 font-bold hover:text-red-600 dark:hover:text-red-300">RESET</button>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* LESSON VIEW OVERLAY */}
        {showLesson && activeUnitId && activeLessonId && (
            <div className="fixed inset-0 bg-white dark:bg-slate-950 z-50 overflow-y-auto animate-in slide-in-from-right duration-300">
                {(() => {
                    const unit = COURSE_DATA.find(u => u.id === activeUnitId)!;
                    const lesson = unit.lessons.find(l => l.id === activeLessonId)!;
                    const isLastLesson = activeLessonId === unit.lessons.length;
                    
                    // Helper to check if lesson has "rich" content or fallback to standard takeaways
                    const hasKeyConcepts = lesson.keyConcepts && lesson.keyConcepts.length > 0;
                    const hasTakeaways = lesson.takeaways && lesson.takeaways.length > 0;

                    return (
                        <div className="max-w-lg mx-auto min-h-screen flex flex-col text-slate-900 dark:text-slate-100">
                            {/* Nav */}
                            <div className="bg-white dark:bg-slate-900 sticky top-0 z-10 px-4 py-3 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800">
                                <button onClick={() => {
                                    triggerHaptic(10);
                                    setShowLesson(false);
                                }} className="p-2 -ml-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition">
                                    <ArrowLeft className="w-5 h-5 text-slate-500 dark:text-slate-300" />
                                </button>
                                <div className="flex-1 min-w-0">
                                    <h3 className="font-bold truncate text-sm text-slate-900 dark:text-white">{lesson.title}</h3>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">Unit {unit.id} • Lesson {lesson.id}</p>
                                </div>
                                <div className="flex items-center gap-1">
                                    <button 
                                        onClick={() => toggleBookmark(unit.id, lesson.id)}
                                        className="p-2 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-full text-rose-500 transition"
                                        title="Favorite this lesson"
                                    >
                                        <Heart className={`w-5 h-5 ${userData.bookmarkedLessons.includes(`${unit.id}-${lesson.id}`) ? 'fill-current' : ''}`} />
                                    </button>
                                    <button 
                                        onClick={handleSaveTimestamp}
                                        className="p-2 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-full text-emerald-600 dark:text-emerald-400 transition"
                                        title="Bookmark current timestamp"
                                    >
                                        <Bookmark className="w-5 h-5" />
                                    </button>
                                </div>
                            </div>

                            {/* Content */}
                            <div className="flex-1">
                                {/* Video Player */}
                                <div className="aspect-video bg-black relative">
                                    {!videoLoaded ? (
                                        <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6 text-center z-10 bg-slate-900">
                                            <div className="text-4xl mb-4">🎬</div>
                                            <p className="text-slate-400 text-sm mb-4">Watch this short video to master the topic</p>
                                            <button 
                                                onClick={() => {
                                                    triggerHaptic(10);
                                                    setVideoLoaded(true);
                                                }}
                                                className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-2 rounded-lg font-medium transition flex items-center gap-2"
                                            >
                                                <Play className="w-4 h-4 fill-white" /> Load Video
                                            </button>
                                            {resumeTime > 0 && (
                                                <p className="text-xs text-emerald-400 mt-4 animate-pulse">
                                                    Resuming from {formatTime(resumeTime)}
                                                </p>
                                            )}
                                        </div>
                                    ) : (
                                        <VideoPlayer 
                                            videoId={lesson.videoId} 
                                            onProgressUpdate={(t) => videoTimeRef.current = t}
                                            startTime={resumeTime}
                                        />
                                    )}
                                </div>

                                <div className="p-5 space-y-8">
                                    <div>
                                        <h2 className="text-xl font-bold mb-4 text-slate-900 dark:text-white">{lesson.title}</h2>
                                        
                                        {/* Key Concepts / Takeaways */}
                                        {(hasKeyConcepts || hasTakeaways) && (
                                            <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl p-4 mb-4">
                                                <h4 className="font-bold text-emerald-600 dark:text-emerald-400 mb-3 text-sm flex items-center gap-2">
                                                    <div className="w-2 h-2 rounded-full bg-emerald-500" /> 
                                                    {hasKeyConcepts ? "Key Concepts" : "Key Takeaways"}
                                                </h4>
                                                <ul className="space-y-3">
                                                    {(lesson.keyConcepts || lesson.takeaways).map((t, i) => (
                                                        <li key={i} className="flex gap-3 text-sm text-slate-700 dark:text-slate-300">
                                                            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                                                            {t}
                                                        </li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}

                                        {/* Formula */}
                                        {lesson.formula && (
                                            <div className="bg-slate-100 dark:bg-slate-900 p-4 rounded-xl mb-4 text-center border border-slate-200 dark:border-slate-800">
                                                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Formula</h4>
                                                <code className="text-lg font-mono font-bold text-emerald-600 dark:text-emerald-400 bg-white dark:bg-slate-950 px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-800 inline-block">
                                                    {lesson.formula}
                                                </code>
                                            </div>
                                        )}
                                        
                                        {/* Visuals */}
                                        {lesson.visual === 'cashflow' && <CashFlowVisual />}

                                        {/* Interactive Element */}
                                        {lesson.interactive === 'budget' && <InteractiveBudget />}
                                        
                                        {/* Worksheet Download */}
                                        {lesson.worksheet && (
                                            <button className="w-full flex items-center justify-center gap-3 p-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition border border-dashed border-slate-300 dark:border-slate-600 mb-4 group">
                                                <div className="p-2 bg-white dark:bg-slate-700 rounded-lg shadow-sm">
                                                    <Download className="w-5 h-5 text-emerald-500" />
                                                </div>
                                                <div className="text-left">
                                                    <span className="block font-bold text-sm text-slate-700 dark:text-slate-200 group-hover:underline">Download Worksheet</span>
                                                    <span className="block text-[10px] text-slate-500 dark:text-slate-400">{lesson.worksheet}</span>
                                                </div>
                                            </button>
                                        )}

                                        {/* Practice Questions (Mini Quiz) */}
                                        {lesson.practice && lesson.practice.length > 0 && (
                                            <div className="mt-8">
                                                <h4 className="font-bold mb-4 flex items-center gap-2 text-lg text-slate-900 dark:text-white">
                                                    <span className="text-xl">✍️</span> Quick Practice
                                                </h4>
                                                <div className="space-y-4">
                                                    {lesson.practice.map((q) => {
                                                        const isAnswered = practiceSubmitted[q.id];
                                                        const isCorrect = practiceAnswers[q.id] === q.answer;
                                                        
                                                        return (
                                                            <div key={q.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-4 shadow-sm">
                                                                <p className="font-medium text-sm mb-3 text-slate-800 dark:text-slate-200">{q.question}</p>
                                                                <div className="space-y-2">
                                                                    {q.options.map((opt, oIdx) => {
                                                                        let btnClass = "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300";
                                                                        if (isAnswered) {
                                                                            if (oIdx === q.answer) btnClass = "bg-emerald-100 dark:bg-emerald-900/30 border-emerald-500 text-emerald-700 dark:text-emerald-400";
                                                                            else if (practiceAnswers[q.id] === oIdx) btnClass = "bg-red-100 dark:bg-red-900/30 border-red-500 text-red-700 dark:text-red-400";
                                                                            else btnClass = "opacity-50 border-slate-200 dark:border-slate-800";
                                                                        } else if (practiceAnswers[q.id] === oIdx) {
                                                                            btnClass = "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-slate-900 dark:text-white";
                                                                        }

                                                                        return (
                                                                            <button
                                                                                key={oIdx}
                                                                                disabled={isAnswered}
                                                                                onClick={() => {
                                                                                    triggerHaptic(5);
                                                                                    setPracticeAnswers(prev => ({...prev, [q.id]: oIdx}))
                                                                                }}
                                                                                className={`w-full text-left px-3 py-2 rounded-lg border text-xs transition-all ${btnClass}`}
                                                                            >
                                                                                {opt}
                                                                            </button>
                                                                        )
                                                                    })}
                                                                </div>
                                                                {!isAnswered && practiceAnswers[q.id] !== undefined && (
                                                                    <button 
                                                                        onClick={() => {
                                                                            triggerHaptic(10);
                                                                            setPracticeSubmitted(prev => ({...prev, [q.id]: true}));
                                                                            if (practiceAnswers[q.id] === q.answer) addXP(10, "Correct Answer!");
                                                                            else triggerHaptic([50, 50]);
                                                                        }}
                                                                        className="mt-3 w-full bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold py-2 rounded-lg hover:bg-slate-800 dark:hover:bg-white"
                                                                    >
                                                                        Check Answer
                                                                    </button>
                                                                )}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        )}

                                        {/* Glossary */}
                                        {lesson.glossary && lesson.glossary.length > 0 && (
                                             <div className="mt-8">
                                                <h4 className="font-bold mb-4 flex items-center gap-2 text-lg text-slate-900 dark:text-white">
                                                    <span className="text-xl">📖</span> Glossary
                                                </h4>
                                                <div className="grid grid-cols-1 gap-3">
                                                    {lesson.glossary.map((term, i) => (
                                                        <div key={i} className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 p-3 rounded-xl">
                                                            <span className="font-bold text-amber-600 dark:text-amber-500 text-sm block mb-1">{term.term}</span>
                                                            <p className="text-xs text-slate-600 dark:text-slate-400">{term.definition}</p>
                                                        </div>
                                                    ))}
                                                </div>
                                             </div>
                                        )}
                                    </div>

                                    {/* Quiz Section (Only on last lesson) */}
                                    {isLastLesson && (
                                        <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 p-5 animate-in slide-in-from-bottom duration-500 delay-150">
                                            <h4 className="font-bold mb-4 flex items-center gap-2 text-slate-900 dark:text-white">
                                                <span className="text-xl">🧠</span> Knowledge Check
                                            </h4>
                                            <div className="space-y-6">
                                                {unit.quiz.map((q, qIdx) => (
                                                    <div key={qIdx}>
                                                        <p className="font-medium text-sm mb-3 text-slate-800 dark:text-slate-200">{qIdx + 1}. {q.question}</p>
                                                        <div className="space-y-2">
                                                            {q.options.map((opt, oIdx) => {
                                                                let stateClass = "border-slate-200 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300";
                                                                if (quizSubmitted) {
                                                                    if (oIdx === q.answer) stateClass = "bg-emerald-100 dark:bg-emerald-900/50 border-emerald-500 dark:border-emerald-500";
                                                                    else if (quizAnswers[qIdx] === oIdx) stateClass = "bg-red-100 dark:bg-red-900/50 border-red-500 dark:border-red-500";
                                                                    else stateClass = "opacity-50 border-slate-200 dark:border-slate-700";
                                                                } else if (quizAnswers[qIdx] === oIdx) {
                                                                    stateClass = "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-slate-900 dark:text-white";
                                                                }

                                                                return (
                                                                    <button
                                                                        key={oIdx}
                                                                        disabled={quizSubmitted}
                                                                        onClick={() => {
                                                                            triggerHaptic(5);
                                                                            const newAnswers = [...quizAnswers];
                                                                            newAnswers[qIdx] = oIdx;
                                                                            setQuizAnswers(newAnswers);
                                                                        }}
                                                                        className={`w-full text-left p-3 rounded-lg border text-sm transition-all ${stateClass}`}
                                                                    >
                                                                        {opt}
                                                                    </button>
                                                                );
                                                            })}
                                                        </div>
                                                    </div>
                                                ))}
                                                
                                                {!quizSubmitted ? (
                                                    <button 
                                                        disabled={quizAnswers.length !== unit.quiz.length}
                                                        onClick={() => handleQuizSubmit(unit.id)}
                                                        className="w-full bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl hover:bg-emerald-600 transition"
                                                    >
                                                        Submit Answers (+50 XP)
                                                    </button>
                                                ) : (
                                                    <div className="text-center text-sm font-bold text-emerald-600 dark:text-emerald-400">Quiz Completed!</div>
                                                )}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Footer Nav */}
                            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 sticky bottom-0 flex gap-3">
                                {activeLessonId > 1 && (
                                    <button 
                                        onClick={() => handleLessonNavigate('prev')}
                                        className="flex-1 py-3 rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition flex items-center justify-center gap-2"
                                    >
                                        <ChevronLeft className="w-4 h-4" /> Prev
                                    </button>
                                )}
                                <button 
                                    onClick={() => handleLessonNavigate('next')}
                                    className="flex-1 py-3 rounded-xl bg-emerald-500 text-white font-bold hover:bg-emerald-600 transition flex items-center justify-center gap-2"
                                >
                                    {isLastLesson ? "Finish Unit" : "Next Lesson"} <ChevronRight className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    );
                })()}
            </div>
        )}

      </main>

      {/* MODALS */}
      {activeCalculator && (
          <CalculatorModal type={activeCalculator} onClose={() => {
              triggerHaptic(10);
              setActiveCalculator(null);
          }} />
      )}

      {/* BOTTOM NAV */}
      {!showLesson && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 z-40 max-w-lg mx-auto">
            <div className="flex justify-around items-center py-2">
                {[
                    { id: 'home', icon: Home, label: 'Home' },
                    { id: 'learn', icon: BookOpen, label: 'Learn' },
                    { id: 'tools', icon: PenTool, label: 'Tools' },
                    { id: 'profile', icon: User, label: 'Profile' }
                ].map(nav => (
                    <button
                        key={nav.id}
                        onClick={() => {
                            triggerHaptic(5);
                            setActiveTab(nav.id as any);
                        }}
                        className={`flex flex-col items-center px-4 py-1.5 transition-colors ${activeTab === nav.id ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-400'}`}
                    >
                        <nav.icon className={`w-6 h-6 mb-1 ${activeTab === nav.id ? 'fill-current' : ''}`} />
                        <span className="text-[10px] font-medium">{nav.label}</span>
                    </button>
                ))}
            </div>
        </nav>
      )}
    </div>
  );
};

export default App;