import { useEffect, useState } from 'react';

export function useProgress() {
  const [progress, setProgress] = useState(() => 
    JSON.parse(localStorage.getItem('finquest-progress') || '[]')
  );

  useEffect(() => {
    localStorage.setItem('finquest-progress', JSON.stringify(progress));
  }, [progress]);

  return [progress, setProgress];
}