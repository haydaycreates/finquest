import React, { useState, useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';
import { X, Calculator, IndianRupee } from 'lucide-react';

interface CalculatorModalProps {
  type: 'budget' | 'sip' | 'emi' | 'compound';
  onClose: () => void;
}

export const CalculatorModal: React.FC<CalculatorModalProps> = ({ type, onClose }) => {
  const [budgetIncome, setBudgetIncome] = useState(50000);
  
  const [sipAmount, setSipAmount] = useState(5000);
  const [sipYears, setSipYears] = useState(10);
  const [sipRate, setSipRate] = useState(12);

  const [emiPrincipal, setEmiPrincipal] = useState(1000000);
  const [emiRate, setEmiRate] = useState(9);
  const [emiTenure, setEmiTenure] = useState(20);

  const [ciPrincipal, setCiPrincipal] = useState(100000);
  const [ciRate, setCiRate] = useState(12);
  const [ciYears, setCiYears] = useState(10);

  // Budget Calculations
  const budget = useMemo(() => ({
    needs: Math.round(budgetIncome * 0.5),
    wants: Math.round(budgetIncome * 0.3),
    savings: Math.round(budgetIncome * 0.2)
  }), [budgetIncome]);

  // SIP Calculations
  const sipData = useMemo(() => {
    const monthlyRate = sipRate / 100 / 12;
    const months = sipYears * 12;
    const futureValue = sipAmount * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate);
    const invested = sipAmount * months;
    const gains = futureValue - invested;
    return { futureValue, invested, gains };
  }, [sipAmount, sipYears, sipRate]);

  // EMI Calculations
  const emiData = useMemo(() => {
    const monthlyRate = emiRate / 100 / 12;
    const months = emiTenure * 12;
    const emi = emiPrincipal * monthlyRate * Math.pow(1 + monthlyRate, months) / (Math.pow(1 + monthlyRate, months) - 1);
    const totalAmount = emi * months;
    const interest = totalAmount - emiPrincipal;
    return { emi, totalAmount, interest };
  }, [emiPrincipal, emiRate, emiTenure]);

  // Compound Interest Calculations & Chart Data
  const ciData = useMemo(() => {
    const simpleInterest = ciPrincipal + (ciPrincipal * ciRate * ciYears / 100);
    const compoundInterest = ciPrincipal * Math.pow(1 + ciRate / 100, ciYears);
    const extra = compoundInterest - simpleInterest;

    const chartData = [];
    for (let i = 0; i <= ciYears; i++) {
       const year = i;
       const si = ciPrincipal + (ciPrincipal * ciRate * year / 100);
       const ci = ciPrincipal * Math.pow(1 + ciRate / 100, year);
       chartData.push({ year, si: Math.round(si), ci: Math.round(ci) });
    }
    return { simpleInterest, compoundInterest, extra, chartData };
  }, [ciPrincipal, ciRate, ciYears]);

  const renderContent = () => {
    switch (type) {
      case 'budget':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2"><Calculator className="w-5 h-5 text-emerald-500" /> 50-30-20 Rule</h3>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Monthly Income (₹)</label>
              <input type="number" value={budgetIncome} onChange={(e) => setBudgetIncome(Number(e.target.value))} className="w-full px-4 py-3 border border-slate-300 dark:border-slate-700 dark:bg-slate-800 rounded-xl focus:ring-2 focus:ring-emerald-500" />
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 space-y-4">
               {/* Needs */}
               <div className="space-y-1">
                 <div className="flex justify-between text-sm"><span className="flex items-center gap-2"><div className="w-3 h-3 bg-blue-500 rounded-full"></div>Needs (50%)</span><span className="font-bold">₹{budget.needs.toLocaleString()}</span></div>
                 <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-blue-500" style={{ width: '50%' }}></div></div>
               </div>
               {/* Wants */}
               <div className="space-y-1">
                 <div className="flex justify-between text-sm"><span className="flex items-center gap-2"><div className="w-3 h-3 bg-amber-500 rounded-full"></div>Wants (30%)</span><span className="font-bold">₹{budget.wants.toLocaleString()}</span></div>
                 <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-amber-500" style={{ width: '30%' }}></div></div>
               </div>
               {/* Savings */}
               <div className="space-y-1">
                 <div className="flex justify-between text-sm"><span className="flex items-center gap-2"><div className="w-3 h-3 bg-emerald-500 rounded-full"></div>Savings (20%)</span><span className="font-bold">₹{budget.savings.toLocaleString()}</span></div>
                 <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden"><div className="h-full bg-emerald-500" style={{ width: '20%' }}></div></div>
               </div>
            </div>
          </div>
        );

      case 'sip':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2"><IndianRupee className="w-5 h-5 text-emerald-500" /> SIP Calculator</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1"><span>Monthly Investment</span><span className="font-bold text-emerald-600">₹{sipAmount}</span></div>
                <input type="range" min="500" max="100000" step="500" value={sipAmount} onChange={(e) => setSipAmount(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1"><span>Period (Years)</span><span className="font-bold text-emerald-600">{sipYears} yrs</span></div>
                <input type="range" min="1" max="30" value={sipYears} onChange={(e) => setSipYears(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1"><span>Expected Return (%)</span><span className="font-bold text-emerald-600">{sipRate}%</span></div>
                <input type="range" min="1" max="30" step="0.5" value={sipRate} onChange={(e) => setSipRate(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl p-5 text-white shadow-lg">
                <p className="text-emerald-100 text-sm">Estimated Corpus</p>
                <p className="text-3xl font-bold">₹{Math.round(sipData.futureValue).toLocaleString()}</p>
                <div className="grid grid-cols-2 gap-4 mt-4 text-sm border-t border-emerald-400/30 pt-4">
                   <div><p className="text-emerald-100">Invested</p><p className="font-semibold">₹{sipData.invested.toLocaleString()}</p></div>
                   <div><p className="text-emerald-100">Wealth Gained</p><p className="font-semibold">₹{Math.round(sipData.gains).toLocaleString()}</p></div>
                </div>
            </div>
          </div>
        );

      case 'emi':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2"><IndianRupee className="w-5 h-5 text-emerald-500" /> EMI Calculator</h3>
            <div className="space-y-4">
              <div>
                 <label className="text-sm font-medium">Loan Amount</label>
                 <input type="number" value={emiPrincipal} onChange={(e) => setEmiPrincipal(Number(e.target.value))} className="w-full mt-1 px-4 py-2 border rounded-lg dark:bg-slate-800 dark:border-slate-700" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1"><span>Interest Rate (%)</span><span className="font-bold text-emerald-600">{emiRate}%</span></div>
                <input type="range" min="5" max="20" step="0.1" value={emiRate} onChange={(e) => setEmiRate(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1"><span>Tenure (Years)</span><span className="font-bold text-emerald-600">{emiTenure} yrs</span></div>
                <input type="range" min="1" max="30" value={emiTenure} onChange={(e) => setEmiTenure(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
              </div>
            </div>

            <div className="bg-slate-900 text-white rounded-xl p-5 text-center">
               <p className="text-slate-400 text-sm">Monthly EMI</p>
               <p className="text-4xl font-bold text-emerald-400">₹{Math.round(emiData.emi).toLocaleString()}</p>
            </div>
            
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
               <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg">
                  <span className="text-slate-500">Principal</span>
                  <p className="font-bold">₹{(emiPrincipal/100000).toFixed(1)}L</p>
               </div>
               <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg">
                  <span className="text-slate-500">Interest</span>
                  <p className="font-bold text-red-500">₹{(emiData.interest/100000).toFixed(1)}L</p>
               </div>
               <div className="bg-slate-100 dark:bg-slate-800 p-2 rounded-lg">
                  <span className="text-slate-500">Total</span>
                  <p className="font-bold">₹{(emiData.totalAmount/100000).toFixed(1)}L</p>
               </div>
            </div>
          </div>
        );

      case 'compound':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold flex items-center gap-2">💹 Compound Interest</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="text-sm">Principal (₹)</label>
                <input type="number" value={ciPrincipal} onChange={(e) => setCiPrincipal(Number(e.target.value))} className="w-full mt-1 px-3 py-2 border rounded-lg dark:bg-slate-800 dark:border-slate-700" />
              </div>
              <div>
                <label className="text-sm">Rate (%)</label>
                <input type="number" value={ciRate} onChange={(e) => setCiRate(Number(e.target.value))} className="w-full mt-1 px-3 py-2 border rounded-lg dark:bg-slate-800 dark:border-slate-700" />
              </div>
              <div>
                <label className="text-sm">Years</label>
                <input type="number" value={ciYears} onChange={(e) => setCiYears(Number(e.target.value))} className="w-full mt-1 px-3 py-2 border rounded-lg dark:bg-slate-800 dark:border-slate-700" />
              </div>
            </div>

            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={ciData.chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorCi" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorSi" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                  <XAxis dataKey="year" hide />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }} 
                    formatter={(value: number) => [`₹${value.toLocaleString()}`, '']}
                  />
                  <Area type="monotone" dataKey="ci" stroke="#10B981" fillOpacity={1} fill="url(#colorCi)" name="Compound" />
                  <Area type="monotone" dataKey="si" stroke="#3B82F6" fillOpacity={1} fill="url(#colorSi)" name="Simple" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl text-center">
                 <p className="text-xs text-blue-600 dark:text-blue-400">Simple Interest</p>
                 <p className="font-bold text-blue-700 dark:text-blue-300">₹{Math.round(ciData.simpleInterest).toLocaleString()}</p>
              </div>
              <div className="bg-emerald-50 dark:bg-emerald-900/20 p-3 rounded-xl text-center">
                 <p className="text-xs text-emerald-600 dark:text-emerald-400">Compound Interest</p>
                 <p className="font-bold text-emerald-700 dark:text-emerald-300">₹{Math.round(ciData.compoundInterest).toLocaleString()}</p>
              </div>
            </div>
            
            <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 p-3 rounded-xl text-center">
               <p className="text-purple-800 dark:text-purple-300 text-sm">✨ Difference: <span className="font-bold">₹{Math.round(ciData.extra).toLocaleString()}</span></p>
            </div>
          </div>
        );
        
      default: return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-t-3xl sm:rounded-2xl max-h-[90vh] overflow-y-auto shadow-2xl animate-in slide-in-from-bottom duration-300">
        <div className="sticky top-0 bg-white dark:bg-slate-900 px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between z-10">
          <span className="font-semibold text-slate-500 dark:text-slate-400">Tool</span>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};