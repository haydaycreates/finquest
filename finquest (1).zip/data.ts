import { Unit, Badge } from './types';

export const BADGES: Badge[] = [
  { id: 1, name: "First Steps", icon: "🌟", description: "Complete your first lesson", requirement: "lesson1" },
  { id: 2, name: "Week Warrior", icon: "🔥", description: "7-day streak", requirement: "streak7" },
  { id: 3, name: "Budget Boss", icon: "💰", description: "Complete Budgeting unit", requirement: "unit2" },
  { id: 4, name: "Credit Master", icon: "💳", description: "Complete Credit unit", requirement: "unit3" },
  { id: 5, name: "Goal Getter", icon: "🎯", description: "Complete Goals unit", requirement: "unit4" },
  { id: 6, name: "Debt Destroyer", icon: "⚔️", description: "Complete Loans unit", requirement: "unit5" },
  { id: 7, name: "Safety Shield", icon: "🛡️", description: "Complete Insurance unit", requirement: "unit6" },
  { id: 8, name: "Investment Pro", icon: "📈", description: "Complete Investment unit", requirement: "unit7" },
  { id: 9, name: "Fraud Fighter", icon: "🚨", description: "Complete Scams unit", requirement: "unit8" },
  { id: 10, name: "Quiz Wizard", icon: "🧙", description: "Pass 10 quizzes", requirement: "quiz10" },
  { id: 11, name: "Halfway Hero", icon: "🏃", description: "Complete 50% of course", requirement: "halfway" },
  { id: 12, name: "Finance Master", icon: "👑", description: "Complete all units", requirement: "complete" }
];

export const COURSE_DATA: Unit[] = [
  {
      id: 1,
      title: "Money Basics",
      icon: "💵",
      color: "bg-emerald-100 dark:bg-emerald-900/30",
      lessons: [
          { 
            id: 1, 
            title: "What is Money?", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Money is a medium of exchange.", "Inflation erodes value over time.", "Compound interest grows wealth."],
            keyConcepts: [
              "Fiat Money: Currency established as money by government regulation.",
              "Compound Interest: Earning interest on both principal and accumulated interest.",
              "Inflation: The rate at which the general level of prices for goods and services is rising.",
              "Opportunity Cost: The potential benefits missed when choosing one alternative over another.",
              "Liquidity: How easily an asset can be converted into ready cash."
            ],
            visual: 'cashflow',
            formula: "A = P(1 + r/n)^(nt)",
            practice: [
              { id: 1, question: "Which of these earns compound interest?", options: ["Cash under mattress", "Savings Account", "Spending", "Piggy bank"], answer: 1 },
              { id: 2, question: "What decreases the purchasing power of money over time?", options: ["Deflation", "Inflation", "Savings", "Coupons"], answer: 1 },
              { id: 3, question: "Fiat money is backed by...", options: ["Gold", "Silver", "Government Trust", "Bitcoin"], answer: 2 },
              { id: 4, question: "If you invest ₹10,000 at 10% annual compound interest, how much will you have after 2 years?", options: ["₹11,000", "₹12,000", "₹12,100", "₹13,000"], answer: 2 },
              { id: 5, question: "Who famously called Compound Interest the '8th wonder of the world'?", options: ["Isaac Newton", "Elon Musk", "Warren Buffett", "Albert Einstein"], answer: 3 },
              { id: 6, question: "In the compound interest formula A=P(1+r/n)^(nt), what does 'P' stand for?", options: ["Profit", "Period", "Principal", "Percentage"], answer: 2 },
              { id: 7, question: "Why is starting to save early important for Compound Interest?", options: ["Interest rates are higher", "Time allows money to compound exponentially", "Banks prefer young customers", "Taxes are lower"], answer: 1 }
            ],
            glossary: [
               { term: "Fiat Money", definition: "Government-issued currency that is not backed by a physical commodity like gold." },
               { term: "Compound Interest", definition: "Interest calculated on the initial principal and also on the accumulated interest." },
               { term: "Inflation", definition: "A general increase in prices and fall in the purchasing value of money." },
               { term: "Principal", definition: "The original sum of money invested or lent." },
               { term: "Asset", definition: "Something valuable that an entity owns, benefits from, or has use of, in generating income." }
            ]
          },
          { 
            id: 2, 
            title: "Budgeting 50/30/20 Rule", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["50% Needs: Essential expenses like rent and food", "30% Wants: Non-essential lifestyle expenses", "20% Savings: Future goals and debt repayment"],
            keyConcepts: [
                "Needs vs Wants: Distinguishing survival costs from lifestyle choices.",
                "Zero-based Budgeting: Assigning every rupee a job.",
                "Discretionary Income: Money left over after paying taxes and essential needs."
            ],
            interactive: 'budget',
            practice: [
                { id: 1, question: "In the 50/30/20 rule, 50% represents?", options: ["Savings", "Wants", "Needs", "Debt"], answer: 2 },
                { id: 2, question: "Dining out at a restaurant is considered a...", options: ["Need", "Want", "Investment", "Tax"], answer: 1 },
                { id: 3, question: "What percentage is allocated to Savings & Investments?", options: ["10%", "20%", "30%", "50%"], answer: 1 },
                { id: 4, question: "Rent and Groceries typically fall under...", options: ["Wants", "Needs", "Savings", "Luxuries"], answer: 1 },
                { id: 5, question: "Which equation represents the rule correctly?", options: ["Needs > Wants", "50+30+20 = 100", "Savings > Needs", "Wants = Needs"], answer: 1 }
            ],
            glossary: [
                { term: "Needs", definition: "Essential expenses required for survival (rent, groceries, utilities)." },
                { term: "Wants", definition: "Non-essential expenses that improve quality of life (dining out, entertainment)." }
            ],
            worksheet: "Budget_Template_v1.pdf"
          },
          { 
            id: 3, 
            title: "Understanding Money Mindset", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Your beliefs about money affect your behavior", "Develop a growth mindset for wealth", "Challenge limiting money beliefs"],
            keyConcepts: [
                "Scarcity Mindset: Believing there is never enough money.",
                "Abundance Mindset: Believing there are limitless opportunities to earn.",
                "Delayed Gratification: Resisting the temptation of immediate reward for a later, greater reward."
            ],
            practice: [
                { id: 1, question: "Which mindset focuses on opportunities?", options: ["Scarcity", "Abundance", "Fear", "Fixed"], answer: 1 },
                { id: 2, question: "What is delayed gratification?", options: ["Buying now", "Waiting for a better reward", "Never spending", "Ignoring money"], answer: 1 },
                { id: 3, question: "A 'Scarcity Mindset' is characterized by...", options: ["Generosity", "Fear of running out", "Investing wisely", "Thinking big"], answer: 1 },
                { id: 4, question: "Unconscious beliefs about money from childhood are called...", options: ["Money Scripts", "Bank Statements", "Credit Scores", "Loans"], answer: 0 },
                { id: 5, question: "To improve financial health, one should cultivate...", options: ["A Growth Mindset", "A Fixed Mindset", "Ignorance", "More Debt"], answer: 0 }
            ],
            glossary: [
                { term: "Money Script", definition: "Unconscious beliefs about money, often developed in childhood." }
            ]
          }
      ],
      quiz: [
          { question: "Why is financial literacy important?", options: ["To impress others", "To make informed money decisions", "It's not important", "Only for rich people"], answer: 1 },
          { question: "What is the first step in your financial journey?", options: ["Buy stocks immediately", "Take a loan", "Set clear financial goals", "Ignore your finances"], answer: 2 },
          { question: "What affects your financial behavior the most?", options: ["Your money mindset", "Your zodiac sign", "The weather", "Your favorite color"], answer: 0 }
      ]
  },
  {
      id: 2,
      title: "Budgeting & Saving",
      icon: "💰",
      color: "bg-blue-100 dark:bg-blue-900/30",
      lessons: [
          { 
            id: 1, 
            title: "The 50/30/20 Rule Explained", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["50% of income goes to Needs (rent, food, bills)", "30% goes to Wants (entertainment, dining out)", "20% goes to Savings & Investments"],
            keyConcepts: ["Budget Allocation", "Financial Discipline", "Tracking Expenses"],
            interactive: 'budget',
            practice: [
                 { id: 1, question: "If your income is ₹30,000, how much should go to savings (20%)?", options: ["₹3,000", "₹6,000", "₹10,000", "₹15,000"], answer: 1 },
                 { id: 2, question: "Which of these is a NEED?", options: ["Netflix Subscription", "Electricity Bill", "New Sneakers", "Weekend Trip"], answer: 1 },
                 { id: 3, question: "If your 'Needs' exceed 50%, you should...", options: ["Cut 'Wants'", "Stop Saving", "Take a Loan", "Ignore it"], answer: 0 },
                 { id: 4, question: "Buying a daily latte is considered a...", options: ["Need", "Want", "Investment", "Tax"], answer: 1 },
                 { id: 5, question: "The first step in creating this budget is...", options: ["Calculating post-tax income", "Spending money", "Buying stocks", "Guessing"], answer: 0 }
            ],
            glossary: [
                { term: "Budget", definition: "An estimation of revenue and expenses over a specified future period of time." }
            ]
          },
          { 
            id: 2, 
            title: "Building Your Emergency Fund", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Save 3-6 months of expenses", "Start with ₹1000 and build up", "Keep it in a separate savings account"],
            keyConcepts: ["Liquidity", "Financial Cushion", "Risk Mitigation"],
            visual: 'cashflow',
            practice: [
                { id: 1, question: "An emergency fund should ideally cover how many months of expenses?", options: ["1 month", "3-6 months", "1 year", "2 weeks"], answer: 1 },
                { id: 2, question: "Where should you keep your emergency fund?", options: ["Stock Market", "Locked FD", "Liquid Savings Account", "Real Estate"], answer: 2 },
                { id: 3, question: "What is a valid reason to use an Emergency Fund?", options: ["Sale on shoes", "Medical Emergency", "Birthday Party", "New Phone"], answer: 1 },
                { id: 4, question: "Why is 'Liquidity' important for an emergency fund?", options: ["To earn high returns", "To access cash quickly", "To avoid taxes", "It's not important"], answer: 1 },
                { id: 5, question: "You should build your emergency fund...", options: ["Before investing heavily", "After retirement", "Only when you lose your job", "Using a credit card"], answer: 0 }
            ],
            glossary: [
                { term: "Emergency Fund", definition: "Money set aside to cover unexpected financial surprises." },
                { term: "Liquidity", definition: "The availability of liquid assets to a market or company." }
            ]
          },
          { 
            id: 3, 
            title: "Smart Saving Strategies", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Automate your savings with SIPs", "Use the pay yourself first method", "Track expenses with apps like Walnut/Money Manager"],
            keyConcepts: ["Automation", "Pay Yourself First", "Expense Tracking"],
            visual: 'cashflow',
            practice: [
                { id: 1, question: "What does 'Pay Yourself First' mean?", options: ["Spend on luxuries first", "Save before spending", "Pay debts last", "Buy gifts for yourself"], answer: 1 },
                { id: 2, question: "Which habit helps most with saving?", options: ["Impulse buying", "Automating transfers", "Ignoring bills", "Checking balance yearly"], answer: 1 },
                { id: 3, question: "Tracking expenses helps you...", options: ["Identify spending leaks", "Earn more income", "Pay fewer taxes", "Forget your budget"], answer: 0 },
                { id: 4, question: "Waiting 24 hours before a big purchase helps avoid...", options: ["Tax", "Impulse Buying", "Saving", "Thinking"], answer: 1 },
                { id: 5, question: "Automation in saving ensures...", options: ["You forget to save", "Consistency and discipline", "High fees", "Lower interest"], answer: 1 }
            ],
            glossary: [
                { term: "Automation", definition: "Setting up automatic transfers to savings to remove willpower from the equation." }
            ]
          }
      ],
      quiz: [
          { question: "In the 50/30/20 rule, what percentage goes to Wants?", options: ["50%", "30%", "20%", "40%"], answer: 1 },
          { question: "How many months of expenses should your emergency fund cover?", options: ["1 month", "3-6 months", "12 months", "No need for emergency fund"], answer: 1 },
          { question: "What does 'pay yourself first' mean?", options: ["Buy things for yourself first", "Save before spending", "Pay your bills first", "Get your salary first"], answer: 1 }
      ]
  },
  {
      id: 3,
      title: "Consumer Credit",
      icon: "💳",
      color: "bg-purple-100 dark:bg-purple-900/30",
      lessons: [
          { 
            id: 1, 
            title: "Understanding CIBIL Score", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["CIBIL scores range from 300-900", "750+ is considered a good score", "It affects your loan interest rates"],
            keyConcepts: ["Creditworthiness", "Credit History", "Credit Mix"],
            practice: [
                { id: 1, question: "What is a 'Good' CIBIL score?", options: ["300", "500", "600", "750+"], answer: 3 },
                { id: 2, question: "Who tracks your credit score?", options: ["RBI", "Credit Bureaus (like CIBIL)", "Your Bank", "Police"], answer: 1 },
                { id: 3, question: "A low CIBIL score can lead to...", options: ["Lower interest rates", "Rejection of loan applications", "Free money", "Better rewards"], answer: 1 },
                { id: 4, question: "Which of these harms your score?", options: ["Paying on time", "Missed EMI payments", "Checking your own score", "Having a savings account"], answer: 1 },
                { id: 5, question: "The range of CIBIL score is...", options: ["0-100", "300-900", "1-10", "100-1000"], answer: 1 }
            ],
            glossary: [
                { term: "CIBIL Score", definition: "A 3-digit number summarizing your credit history and repayment behavior." }
            ]
          },
          { 
            id: 2, 
            title: "Credit Cards: Friend or Foe?", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Always pay full balance before due date", "Never use credit for things you can't afford", "Rewards can be beneficial if used wisely"],
            keyConcepts: ["Interest-Free Period", "Minimum Amount Due Trap", "Rewards Points"],
            practice: [
                { id: 1, question: "If you only pay the 'Minimum Amount Due', what happens?", options: ["Nothing", "You pay heavy interest on the rest", "Bank thanks you", "Score increases"], answer: 1 },
                { id: 2, question: "The best way to use a credit card is...", options: ["Max out the limit", "Pay fully every month", "Withdraw cash", "Hide it"], answer: 1 },
                { id: 3, question: "What is the typical interest-free period?", options: ["1 year", "45-50 days", "1 week", "No free period"], answer: 1 },
                { id: 4, question: "Withdrawing cash from a credit card attracts...", options: ["No interest", "Instant high interest", "Bonus points", "Discounts"], answer: 1 },
                { id: 5, question: "Using a credit card responsibly helps build...", options: ["Debt", "Credit History", "Inflation", "Savings"], answer: 1 }
            ],
            glossary: [
                { term: "Minimum Amount Due", definition: "Smallest amount you must pay to avoid late fees, but interest still charges." }
            ]
          },
          { 
            id: 3, 
            title: "Building Good Credit", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Pay all EMIs on time", "Keep credit utilization below 30%", "Check your credit report regularly"],
            keyConcepts: ["Credit Utilization Ratio", "Repayment History", "Hard Enquiries"],
            practice: [
                { id: 1, question: "What is an ideal Credit Utilization Ratio?", options: ["0%", "Below 30%", "100%", "Over 50%"], answer: 1 },
                { id: 2, question: "Does checking your own score lower it?", options: ["Yes", "No", "Only on Tuesdays", "Sometimes"], answer: 1 },
                { id: 3, question: "Applying for many loans at once causes...", options: ["Hard Enquiries", "Soft Enquiries", "No impact", "Score increase"], answer: 0 },
                { id: 4, question: "How long does a missed payment stay on record?", options: ["1 month", "A few years", "Forever", "1 day"], answer: 1 },
                { id: 5, question: "A healthy 'Credit Mix' includes...", options: ["Only personal loans", "Only credit cards", "Secured and Unsecured loans", "No loans"], answer: 2 }
            ],
            glossary: [
                { term: "Credit Utilization", definition: "The percentage of your total credit limit that you are currently using." }
            ]
          }
      ],
      quiz: [
          { question: "What is considered a good CIBIL score?", options: ["300-500", "500-650", "750+", "Any score"], answer: 2 },
          { question: "What should you do with credit card balance?", options: ["Pay minimum amount", "Pay full balance before due date", "Ignore it", "Pay whenever you can"], answer: 1 },
          { question: "What credit utilization ratio is ideal?", options: ["Below 30%", "50%", "80%", "100%"], answer: 0 }
      ]
  },
  {
      id: 4,
      title: "Financial Goals",
      icon: "🎯",
      color: "bg-amber-100 dark:bg-amber-900/30",
      lessons: [
          { 
            id: 1, 
            title: "SMART Goal Setting", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Specific: Define exactly what you want", "Measurable: Track your progress", "Achievable, Relevant, Time-bound"],
            keyConcepts: ["Specific", "Measurable", "Time-bound"],
            visual: 'cashflow',
            practice: [
                { id: 1, question: "In SMART goals, what does 'T' stand for?", options: ["Total", "Time-bound", "Technical", "Test"], answer: 1 },
                { id: 2, question: "Which is a SMART goal?", options: ["I want to be rich", "I will save ₹1 Lakh for a car by Dec 2024", "I need money", "Save as much as possible"], answer: 1 },
                { id: 3, question: "M stands for...", options: ["Money", "Measurable", "Many", "Major"], answer: 1 },
                { id: 4, question: "Why should goals be written down?", options: ["To forget them", "For accountability", "It's a rule", "To waste paper"], answer: 1 },
                { id: 5, question: "A goal must be 'A' - Achievable. This means...", options: ["It's impossible", "It's realistic", "It's too easy", "It's vague"], answer: 1 }
            ],
            glossary: [
                { term: "SMART", definition: "Acronym for Specific, Measurable, Achievable, Relevant, Time-bound." }
            ]
          },
          { 
            id: 2, 
            title: "Calculating Your Net Worth", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Net Worth = Assets - Liabilities", "Track it monthly or quarterly", "Aim for positive and growing net worth"],
            keyConcepts: ["Assets", "Liabilities", "Equity"],
            formula: "Net Worth = Total Assets - Total Liabilities",
            practice: [
                { id: 1, question: "A home loan is considered a...", options: ["Asset", "Liability", "Income", "Expense"], answer: 1 },
                { id: 2, question: "If Assets = 10L and Liabilities = 4L, Net Worth is?", options: ["14L", "6L", "40L", "0L"], answer: 1 },
                { id: 3, question: "Which of these is an Asset?", options: ["Credit Card Debt", "Savings Account Balance", "Unpaid Bills", "Car Loan"], answer: 1 },
                { id: 4, question: "A positive net worth means...", options: ["You owe more than you own", "You own more than you owe", "You have zero money", "You are bankrupt"], answer: 1 },
                { id: 5, question: "You should track net worth...", options: ["Daily", "Periodically (e.g. Quarterly)", "Never", "Once in a lifetime"], answer: 1 }
            ],
            glossary: [
                { term: "Net Worth", definition: "The value of everything you own minus everything you owe." },
                { term: "Liability", definition: "Debts or financial obligations (loans, mortgages)." }
            ]
          },
          { 
            id: 3, 
            title: "Short vs Long-term Goals", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Short-term: 0-2 years (phone, vacation)", "Medium-term: 2-5 years (car, education)", "Long-term: 5+ years (house, retirement)"],
            keyConcepts: ["Time Horizon", "Risk Tolerance", "Inflation Adjustment"],
            practice: [
                { id: 1, question: "Saving for retirement (30 years away) is a...", options: ["Short-term goal", "Medium-term goal", "Long-term goal", "Daily goal"], answer: 2 },
                { id: 2, question: "For short-term goals, you should invest in...", options: ["High-risk stocks", "Low-risk liquid funds", "Real Estate", "Crypto"], answer: 1 },
                { id: 3, question: "A vacation next year is a...", options: ["Long-term goal", "Short-term goal", "Liability", "Emergency"], answer: 1 },
                { id: 4, question: "Inflation impacts which goals the most?", options: ["Short-term", "Long-term", "Yesterday's", "None"], answer: 1 },
                { id: 5, question: "Risk tolerance should be _____ for long-term goals.", options: ["Lower", "Higher", "Zero", "Negative"], answer: 1 }
            ],
            glossary: [
                { term: "Time Horizon", definition: "The length of time over which an investment is made or held before it is liquidated." }
            ]
          }
      ],
      quiz: [
          { question: "What does SMART stand for in goal setting?", options: ["Simple, Modern, Actual, Real, Total", "Specific, Measurable, Achievable, Relevant, Time-bound", "Save More And Retire Tomorrow", "None of these"], answer: 1 },
          { question: "How do you calculate net worth?", options: ["Income - Expenses", "Assets - Liabilities", "Savings + Investments", "Salary × 12"], answer: 1 },
          { question: "A home purchase is typically what type of goal?", options: ["Short-term", "Medium-term", "Long-term", "Not a financial goal"], answer: 2 }
      ]
  },
  {
      id: 5,
      title: "Loans & Debt",
      icon: "🏦",
      color: "bg-red-100 dark:bg-red-900/30",
      lessons: [
          { 
            id: 1, 
            title: "Good Debt vs Bad Debt", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Good debt helps build wealth (education, home)", "Bad debt finances depreciating items", "Always evaluate ROI before borrowing"],
            keyConcepts: ["ROI (Return on Investment)", "Depreciation", "Leverage"],
            practice: [
                { id: 1, question: "Which is generally considered 'Bad Debt'?", options: ["Home Loan", "Business Loan", "Credit Card Debt for Vacation", "Education Loan"], answer: 2 },
                { id: 2, question: "Good debt typically...", options: ["Loses value", "Increases net worth/income", "Has 50% interest", "Is illegal"], answer: 1 },
                { id: 3, question: "Depreciation means...", options: ["Value increases", "Value decreases", "Price stays same", "Profit"], answer: 1 },
                { id: 4, question: "An education loan is good debt because...", options: ["It's free", "It increases earning potential", "Banks like it", "It looks cool"], answer: 1 },
                { id: 5, question: "Buying a luxury car on loan is bad debt because...", options: ["Cars depreciate", "Cars appreciate", "Fuel is cheap", "Roads are bad"], answer: 0 }
            ],
            glossary: [
                { term: "ROI", definition: "Return on Investment - a measure used to evaluate the efficiency of an investment." }
            ]
          },
          { 
            id: 2, 
            title: "Understanding EMI", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["EMI = Equated Monthly Installment", "Consists of principal + interest", "Use EMI calculators before taking loans"],
            keyConcepts: ["Principal", "Interest Rate", "Tenure", "Amortization"],
            formula: "EMI = [P x R x (1+R)^N]/[(1+R)^N-1]",
            practice: [
                { id: 1, question: "In an EMI, in the early years, a larger portion goes towards...", options: ["Principal", "Interest", "Taxes", "Insurance"], answer: 1 },
                { id: 2, question: "If you increase tenure, your EMI...", options: ["Increases", "Decreases", "Stays same", "Doubles"], answer: 1 },
                { id: 3, question: "EMI stands for...", options: ["Easy Monthly Income", "Equated Monthly Installment", "Equal Money Investment", "Every Month Interest"], answer: 1 },
                { id: 4, question: "Prepaying a loan reduces...", options: ["Principal balance", "Bank profits", "Your credit score", "Processing fees"], answer: 0 },
                { id: 5, question: "A fixed interest rate means...", options: ["EMI changes every month", "EMI stays constant", "Rate depends on market", "No interest"], answer: 1 }
            ],
            glossary: [
                { term: "Amortization", definition: "The process of spreading out a loan into a series of fixed payments." }
            ]
          },
          { 
            id: 3, 
            title: "Debt Repayment Strategies", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Snowball: Pay smallest debt first", "Avalanche: Pay highest interest first", "Always pay more than minimum"],
            keyConcepts: ["Debt Snowball", "Debt Avalanche", "Consolidation"],
            visual: 'cashflow',
            practice: [
                { id: 1, question: "The Debt Snowball method focuses on paying which debt first?", options: ["Highest Interest", "Smallest Balance", "Largest Balance", "Oldest Debt"], answer: 1 },
                { id: 2, question: "The Debt Avalanche method saves more on...", options: ["Time", "Interest", "Paperwork", "Fees"], answer: 1 },
                { id: 3, question: "Debt Consolidation involves...", options: ["Ignoring debts", "Taking one loan to pay off many", "Filing bankruptcy", "Paying nothing"], answer: 1 },
                { id: 4, question: "Which method provides quick psychological wins?", options: ["Avalanche", "Snowball", "Ignoring", "Minimum Payment"], answer: 1 },
                { id: 5, question: "Always paying only the minimum due leads to...", options: ["Debt freedom", "Debt trap", "High score", "Savings"], answer: 1 }
            ],
            glossary: [
                { term: "Debt Consolidation", definition: "Taking out a new loan to pay off other debts, combining them into a single payment." }
            ]
          }
      ],
      quiz: [
          { question: "Which is typically considered 'good debt'?", options: ["Credit card debt for shopping", "Education loan", "Personal loan for vacation", "Payday loan"], answer: 1 },
          { question: "What does EMI consist of?", options: ["Only interest", "Only principal", "Principal + Interest", "Processing fee"], answer: 2 },
          { question: "In the avalanche method, you pay off ___ first.", options: ["Smallest debt", "Oldest debt", "Highest interest debt", "Newest debt"], answer: 2 }
      ]
  },
  {
      id: 6,
      title: "Investments & Retirement",
      icon: "📈",
      color: "bg-green-100 dark:bg-green-900/30",
      lessons: [
          { 
            id: 1, 
            title: "Introduction to Mutual Funds", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["Pool money from multiple investors", "Professionally managed portfolios", "Start with as low as ₹500/month SIP"],
            keyConcepts: ["Diversification", "NAV (Net Asset Value)", "Expense Ratio", "Equity vs Debt"],
            practice: [
                { id: 1, question: "Mutual funds are managed by...", options: ["Robots", "Professional Fund Managers", "Government", "Random people"], answer: 1 },
                { id: 2, question: "Diversification helps to...", options: ["Increase risk", "Reduce risk", "Double money instantly", "Avoid taxes"], answer: 1 },
                { id: 3, question: "NAV stands for...", options: ["New Asset Value", "Net Asset Value", "Net Amount Verified", "New Account Verify"], answer: 1 },
                { id: 4, question: "Equity Mutual Funds invest primarily in...", options: ["Gold", "Stock Market", "Government Bonds", "Real Estate"], answer: 1 },
                { id: 5, question: "An Expense Ratio is...", options: ["Fee charged by the fund", "Profit you make", "Tax you pay", "Discount you get"], answer: 0 }
            ],
            glossary: [
                { term: "Diversification", definition: "Spreading investments across various assets to reduce exposure to risk." },
                { term: "NAV", definition: "Net Asset Value - the price per share/unit of a mutual fund." }
            ]
          },
          { 
            id: 2, 
            title: "Power of SIP", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["SIP = Systematic Investment Plan", "Benefit from rupee cost averaging", "Start early for compounding benefits"],
            keyConcepts: ["Rupee Cost Averaging", "Consistency", "Compounding"],
            visual: 'cashflow',
            practice: [
                { id: 1, question: "What happens when markets fall in a SIP?", options: ["You lose everything", "You buy more units at lower price", "SIP stops", "You pay a fine"], answer: 1 },
                { id: 2, question: "SIP is best for...", options: ["Timing the market", " disciplined, long-term investing", "Day trading", "Gambling"], answer: 1 },
                { id: 3, question: "Rupee Cost Averaging helps in...", options: ["Buying low and selling high", "Averaging out purchase cost", "Avoiding taxes", "Predicting market"], answer: 1 },
                { id: 4, question: "You can start a SIP with as low as...", options: ["₹1 Lakh", "₹500", "₹10,000", "₹50,000"], answer: 1 },
                { id: 5, question: "The key to SIP success is...", options: ["Stopping when market falls", "Consistency over time", "Changing funds monthly", "Checking daily"], answer: 1 }
            ],
            glossary: [
                { term: "Rupee Cost Averaging", definition: "Buying more units when prices are low and fewer when high, averaging cost over time." }
            ]
          },
          { 
            id: 3, 
            title: "Retirement Planning: PPF & NPS", 
            videoId: "Uo0KjdDJr1c", 
            takeaways: ["PPF: Safe, tax-free returns (~7-8%)", "NPS: Market-linked retirement savings", "Start in your 20s for best results"],
            keyConcepts: ["Corpus", "Inflation", "Tax Benefits (80C)", "Annuity"],
            practice: [
                { id: 1, question: "PPF currently offers returns around...", options: ["2-3%", "7-8%", "15-20%", "50%"], answer: 1 },
                { id: 2, question: "NPS stands for?", options: ["National Pension System", "New Public Scheme", "No Pension Scheme", "National Profit System"], answer: 0 },
                { id: 3, question: "The lock-in period for PPF is...", options: ["1 year", "5 years", "15 years", "Lifetime"], answer: 2 },
                { id: 4, question: "NPS invests your money in...", options: ["Only Gold", "Mix of Equity, Corporate & Govt Debt", "Cash only", "Real Estate only"], answer: 1 },
                { id: 5, question: "Why start retirement planning early?", options: ["To benefit from compounding", "You can't start late", "Banks force you", "To retire at 30"], answer: 0 }
            ],
            glossary: [
                { term: "Annuity", definition: "A fixed sum of money paid to someone each year, typically for the rest of their life." }
            ]
          }
      ],
      quiz: [
          { question: "What is a SIP?", options: ["Single Investment Plan", "Systematic Investment Plan", "Special Insurance Policy", "Stock Investment Portal"], answer: 1 },
          { question: "What is the minimum SIP amount in most mutual funds?", options: ["₹10,000", "₹5,000", "₹500", "₹1 lakh"], answer: 2 },
          { question: "PPF stands for?", options: ["Personal Provident Fund", "Public Provident Fund", "Private Pension Fund", "Public Pension Fund"], answer: 1 }
      ]
  }
];